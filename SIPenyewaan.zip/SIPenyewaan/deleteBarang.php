<!-- <?php
include 'koneksi.php';
// menyimpan data id kedalam variabel
$id_barang   = $_GET['ID_BARANG'];
// query SQL untuk insert data
$query="DELETE from barang where ID_BARANG='$id_barang'";
mysqli_query($koneksi, $query);
// mengalihkan ke halaman index.php
header("location:index.php");
?> -->

<?php
	session_start();
	include 'koneksi.php'; 

	if(isset($_GET['ID_BARANG'])){
		if(empty($_GET['ID_BARANG'])){
			echo "<b>Data yang dihapus tidak ada</b>";
		}
		else{
			$delete = mysqli_query($koneksi, "DELETE FROM barang WHERE ID_BARANG='$_GET[ID_BARANG]'") or die ("data salah: ".mysqli_error($koneksi));
				if($delete){
					header("Location:dataBarang.php");
				}
		}
	}
?> 