<?php

include "koneksi.php"; //memanggil file koneksi.php untuk menghubungkan ke database


  if(isset($_POST['simpan'])) {

    $nama= $_POST['NAMA'];
    $username = $_POST['USERNAME'];
    $password = $_POST['PASSWORD'];
    $email = $_POST['EMAIL'];
    $alamat = $_POST['ALAMAT'];
    $level = $_POST['LEVEL'];
    $gambar = $_FILES['GAMBAR_USER']['name'];
	$lokasi_file = $_FILES['GAMBAR_USER']['tmp_name'];

    $path = "img/".$gambar;

    move_uploaded_file($lokasi_file, $path);

    $user = mysqli_query($koneksi, "INSERT INTO user SET NAMA= '$nama',USERNAME='$username',PASSWORD='$password',EMAIL='$email',ALAMAT='$alamat',LEVEL=1, GAMBAR_USER ='$gambar'") or die ("data salah: ".mysqli_error($koneksi));

  if ($user) {
		echo "<script>alert('Berhasil di tambahkan!');history.go(-1);</script>";
		

	}else{
		echo "<script>alert('gagal di tambahkan!');history.go(-1);</script>";
		
	}
        // Show message when user added
        
    }

    ?>

