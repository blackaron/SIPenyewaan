<?php
	session_start();
	if(!isset($_SESSION['USERNAME']) ){
	echo"<script>window.alert('maaf anda harus login terlebih dahulu')</script>";
	echo"<script>window.location=('index.php')</script>";
	exit();
}


include "koneksi.php";

if(isset($_POST['simpan'])){
// memanggil nama variabel id untuk dibuat menjadi variabel baru $id
	// $id_pinjam = $_POST['id_pinjam'];
	$tanggal_reservasi =date("Y/m/d");
	$tanggal_pinjam= $_POST['TGL_PINJAM'];
	$tanggal_kembali = $_POST['TGL_KEMBALI'];

	$booking    =new DateTime($_POST['TGL_PINJAM']);
        $ambil        =new DateTime($_POST['TGL_KEMBALI']);
        $diff         =$ambil->diff($booking);
        $hari =  $diff->d;

	$nama = $_POST['NAMA'];
	$nama_barang= $_POST['NAMA_BARANG'];
	$jumlah_sewa = $_POST['JUMLAH_SEWA'];
	$harga_sewa = $_POST['HARGA_SEWA'];
	$jaminan = $_POST['JAMINAN'];
	$no_identitas = $_POST['NO_IDENTITAS'];
	$metode_pengambilan = $_POST['METODE_PENGAMBILAN'];
	$alamat_kirim= $_POST['ALAMAT_KIRIM'];
	$stok = $_POST['JUMLAH_STOK'];
	// $total_sewa= $_POST['TOTAL_SEWA'];

	$total_sewa = $harga_sewa * $jumlah_sewa * $hari;
	$gagalAmbilData = false;
	if ($metode_pengambilan=="Dikirim Ke Alamat Pengiriman") {
		if ((!empty($alamat_kirim)) && $alamat_kirim!='-') {
			//proses hitung jarak
			// make request
			$request_alamat = str_replace(" ", "%20", $alamat_kirim);
			$request_alamat .= "%20Malang";
			$url = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=Ciliwung%20Camp%20Malang&destinations=".$request_alamat."&key=AIzaSyA5xaA_PWRWUrhy9OG8cmThQKJecyxhtlE";
			$response = file_get_contents($url);
		    $output_data = json_decode($response, TRUE, JSON_PRETTY_PRINT);
		    // echo json_encode($output_data['rows'][0]['elements'][0]);
		      if (!empty($output_data)) {
				if (strtolower($output_data['rows'][0]['elements'][0]['status'])=="ok") {
					$jarak = 0;
					if (isset($output_data['rows'][0]['elements'][0]['distance']['value'])) {
						$jarak += $output_data['rows'][0]['elements'][0]['distance']['value'];
					}
					//hitung tarif
					$tarif = 0.4; // patokan tarif permeter
					if ($jarak!=0) {
						$total_sewa += $tarif*$jarak;
					}
				}else{
					$gagalAmbilData = true;
				}
		    }else{
		    	$gagalAmbilData = true;
		    }
		}else{
			$gagalAmbilData = true;
		}
	}

	//untuk mengetahui apakah gagal mengambil data atau
	if (!$gagalAmbilData) {
			// menambahkan query sql tambah data untuk menambahkan untuk data ke database
			if (isset($jarak)) {
				$data = mysqli_query($koneksi,"INSERT INTO reservasi set TGL_RESERVASI='$tanggal_reservasi', TGL_PINJAM='$tanggal_pinjam',TGL_KEMBALI='$tanggal_kembali', ID_USER='$id_user', ID_BARANG='$id_barang', JUMLAH_SEWA='$jumlah_sewa', 	TOTAL_HARGA='$total_sewa', JAMINAN='$jaminan', NO_IDENTITAS='$no_identitas', METODE_PENGAMBILAN='$metode_pengambilan', ALAMAT_KIRIM='$alamat_kirim', JARAK='$jarak'") or die ("data salah : ".mysqli_error($koneksi));
			}else{
				$data = mysqli_query($koneksi,"INSERT INTO reservasi set TGL_RESERVASI='$tanggal_reservasi', TGL_PINJAM='$tanggal_pinjam',TGL_KEMBALI='$tanggal_kembali', ID_USER='$id_user', ID_BARANG='$id_barang', JUMLAH_SEWA='$jumlah_sewa', 	TOTAL_HARGA='$total_sewa', JAMINAN='$jaminan', NO_IDENTITAS='$no_identitas', METODE_PENGAMBILAN='$metode_pengambilan', ALAMAT_KIRIM='$alamat_kirim'") or die ("data salah : ".mysqli_error($koneksi));
			}

			//mengurangi stok
			$totalStok = $stok - $jumlah_sewa;
			$data = mysqli_query($koneksi,"UPDATE BARANG set STOK='$totalStok' WHERE ID_BARANG='$id_barang'") or die ("data salah : ".mysqli_error($koneksi));


			// untuk menPOSTahui apakah data berhasil disimpan atau belum
			if ($data) {
				echo "Berhasil Mengirim Data";
				header("Location: riwayat2.php");

			}else{
				echo "Gagal Mengirim Data!!";
				echo "<br><a href='isiformsewa2.php'>Kembali </a>"; // berfungsi untuk ngelink kke halaman tampil.php
			}
	}else{
		echo "Alamat tidak ditemukan!!";
		echo "<br><a href='isiformsewa2.php'>Kembali </a>"; // berfungsi untuk ngelink kke halaman tampil.php
	}
}

?>



<!-- TOTAL_HARGA=$total_harga, TOTAL_SEWA=$total_sewa -->