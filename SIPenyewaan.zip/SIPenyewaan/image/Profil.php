<?php
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
}
include "koneksi.php";

//QUERY AMBIL ID YG SEDANG LOGIN
$nama = $_SESSION['username'];
$ambilID = mysqli_query($mysqli, "SELECT IDUSER FROM USER WHERE USERNAME='$nama'") or die ("data salah: ".mysqli_error($mysqli));
while ($show = mysqli_fetch_array($ambilID)) {
    $idUser =$show['IDUSER'];
}

//QUERY MENAMPILKAN DATA USER YANG SEDANG LOGIN
$dataUser = mysqli_query($mysqli, "SELECT * FROM USER WHERE USERNAME='$nama'");

//QUERY DATABARANG
$dataBarang = mysqli_query($mysqli, "SELECT * FROM BarangMasuk WHERE IDUSER='$idUser'");

//QUERY RIWAYAT
$riwayatBeli = mysqli_query($mysqli, "SELECT * FROM barangkeluar WHERE IDUSER='$idUser'");


//QUERY NAMA PEMBELI YANG MINTA DIKONFIRMASI
$queryNamaPembeli = mysqli_query($mysqli, " SELECT us.NAMAUSER FROM transaksi as tr INNER JOIN user as us on tr.IDPEMBELI = us.IDUSER");
while ($show = mysqli_fetch_array($queryNamaPembeli)) {
    $namaPembeli = $show['NAMAUSER'];
}

$jumlahNotif = mysqli_query($mysqli, " SELECT COUNT(STATUS) AS NOTIF FROM transaksi WHERE STATUS = 'Belum Dikonfirmasi' AND IDPENJUAL='$idUser'");
while ($show = mysqli_fetch_array($jumlahNotif)) {
    $jumlahNotifikasi = $show['NOTIF'];
}

//QUERY KONFIRMASI
$dataKonfirmasi = mysqli_query($mysqli, "
    SELECT tr.IDTRANSAKSI, us.NAMAUSER, tr.IDPEMBELI,bm.NAMABARANG,tr.HARGABARANG, tr.JUMLAHBARANG, tr.TANGGALTRANSAKSI, tr.TOTALHARGA, tr.STATUS, us.NOHP
    FROM transaksi as tr INNER JOIN user as us on tr.IDPEMBELI = us.IDUSER
    INNER JOIN barangmasuk as bm on tr.IDBARANG = bm.IDBM WHERE tr.IDPENJUAL = '$idUser' "
);

$jumlahBeli = mysqli_query($mysqli, "SELECT SUM(JUMLAHBARANG) as JUMLAHBARANG , SUM(TOTALHARGA) AS TOTAL FROM barangkeluar WHERE IDUSER='$idUser'");


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>PROFIL</title>

    <!-- Favicons -->
    <link href="profilcss/img/favicon.png" rel="icon">
    <link href="profilcss/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Bootstrap core CSS -->
    <link href="profilcss/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--external css-->
    <link href="profilcss/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="profilcss/css/style.css" rel="stylesheet">
    <link href="profilcss/css/style-responsive.css" rel="stylesheet">

</head>

<body>
    <section id="container">
<!-- **********************************************************************************************************************************************************
TOP BAR CONTENT & NOTIFICATIONS
*********************************************************************************************************************************************************** -->
<!--header start-->
<header class="header black-bg">

    <!--logo start-->
    <a href="index.php" class="logo"><img src="image/LOGO.png" style="width:50px" height="35px">TANIKU</a>
    <!--logo end-->
    <div class="top-menu">
        <ul class="nav pull-right top-menu">
            <li><a class="logout" href="Proses/logout.php">Logout</a></li>
        </ul>
    </div>
</header>
<!--header end-->
<!-- **********************************************************************************************************************************************************
MAIN CONTENT
*********************************************************************************************************************************************************** -->
<!--main content start-->
<section id="main-content" style="padding-right: 250px">
    <section class="wrapper site-min-height">
        <div class="row mt">
            <div class="col-lg-12">
                <div class="row content-panel">
                    <div class="col-md-4 profile-text mt mb centered" style="padding-right:90px; padding-left:90px">
                        <h8>
                            <a href="" class="btn btn-primary btn-block pull-right" role="button" data-toggle="modal" data-target="#exampleModal">
                                <span class="glyphicon glyphicon-plus"></span> 
                                Tambah Barang
                            </a>
                        </h8>
                        <br><br>
                        <h8>
                            <a href="editprofil.php?ID=10" class="btn btn-info btn-block pull-right" role="button" data-toggle="modal" data-target="#exampleModal2">
                                <span class="glyphicon glyphicon-cog"></span> 
                                Edit Profil
                            </a>
                        </h8>
                    </div>
                    <!-- /col-md-4 -->
                    <div class="col-md-4 profile-text">
                        <?php  
                        while ($show = mysqli_fetch_array($dataUser)) {
                            ?>
                            <h3><?php echo $show['NAMAUSER']; ?></h3>
                            <p><?php echo $show['NOHP'];?></p>
                            <p><?php echo $show['EMAIL'];?></p>
                            <p><?php echo $show['ALAMAT'];?></p>
                        </div>
                        <!-- /col-md-4 -->
                        <div class="col-md-4 centered">
                            <div class="profile-pic">
                                <p><?php echo "<img src='Proses/gambar/".$show['GAMBAR']."'>";?></p>
                            <?php }?>
                        </div>
                    </div>
                    <!-- /col-md-4 -->
                </div>
                <!-- /row -->
            </div>
            <!-- /col-lg-12 -->
            <div class="col-lg-12 mt">
                <div class="row content-panel">
                    <div class="panel-heading">
                        <ul class="nav nav-tabs nav-justified">
                            <li class="active">
                                <a data-toggle="tab" href="#databarang">Data Barang</a>
                            </li>
                            <li>
                                <a data-toggle="tab" href="#riwayatbeli" >Riwayat Beli</a>
                            </li>
                            <li>
                                <?php 
                                if ($jumlahNotifikasi < 1) { ?>
                                    <a data-toggle="tab" href="#konfirmasi">Konfirmasi</a>'
                             <?php   }else{ ?>
                                    <a data-toggle="tab" href="#konfirmasi">Konfirmasi<sup ><b ><mark style="color: red;"><?php echo $jumlahNotifikasi; ?></mark></b></sup></a>'
                               <?php }

                                ?>
                                
                            </li>
                        </ul>
                    </div>
                    <!-- /panel-heading -->
                    <div class="panel-body">
                        <div class="tab-content">
                            <!-- /tab-pane databarang -->
                            <div id="databarang" class="tab-pane active">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="content-panel">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <!-- <th class="idBarang">ID</th> -->
                                                        <th class="gambar">Gambar</th>
                                                        <th class="namaBarang">Nama Barang</th>
                                                        <th class="hargabarang">Harga Barang</th>
                                                        <th class="jumlah">Jumlah</th>
                                                        <th class="satuan">Satuan</th>
                                                        <th class="deskripsi">Detail</th>
                                                        <th class="tools">Tools</th>
                                                    </tr>
                                                </thead>
                                                <?php 
                                                while ($show = mysqli_fetch_array($dataBarang)) {
                                                    $namaBarangnya = $show['NAMABARANG'];
                                                    ?>
                                                    <tbody>
                                                        <tr>
                                                            <?php echo "<td><img src='Proses/gambar/".$show['GAMBAR']."' width='100' height='100'></td>";?>
                                                            <td><?php echo $show['NAMABARANG'];?></td>
                                                            <td>Rp. <?php echo $show['HARGABARANG'];?></td>
                                                            <td><?php echo $show['JUMLAH'];?></td>
                                                            <td><?php echo $show['SATUAN'];?></td>
                                                            <td><?php echo $show['DESKRIPSI'];?></td>
                                                            <td>
                                                                <a href="Proses/deletesql.php?IDBM=<?php echo $show['IDBM']?>" class="btn btn-danger btn-sm" onclick="return confirm('<?="Yakin Menghapus $namaBarangnya"?>')"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                                                                <a href="edit.php?IDBM=<?php echo $show['IDBM']; ?>" data-toggle="modal" data-target="#ModalEdit" class="btn btn-primary btn-sm">
                                                                    <span class="glyphicon glyphicon-edit"> </span> Edit
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <!-- modal tambah -->
                                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h2 class="modal-title" id="exampleModalLabel">Tambah Barang</h2>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="Proses/tambahbarangsql.php" role="form" method="post" enctype="multipart/form-data">
                                                        <div class="col-lg-12">
                                                            <div class="form-group">
                                                                <label for="gambar">Upload Gambar</label>
                                                                <div class="input-group">
                                                                    <input name="gambar" type="file" class="form-control">
                                                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="nama">Nama Barang</label>
                                                                <div class="input-group">
                                                                    <input type="text" class="form-control" name="namabarang" placeholder="Masukkan Nama Barang" required>
                                                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="nama">Harga Barang</label>
                                                                <div class="input-group">
                                                                    <input type="text" class="form-control" name="hargabarang" placeholder="Masukkan Harga" required>
                                                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="nama">Jumlah Barang</label>
                                                                <div class="input-group">
                                                                    <input type="text" class="form-control" name="jmlbarang" placeholder="Masukkan Jumlah" value="<?php echo $show['JUMLAH'];?>">
                                                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="nama">Satuan Barang</label>
                                                                <div class="form-group">
                                                                    <select name="satuan" class="form-control" value="<?php echo $show['SATUAN'];?>">
                                                                        <option >--Pilih Satuan--</option>
                                                                        <option value="/Biji">/biji</option>
                                                                        <option value="/Ikat">/ikat</option>
                                                                        <option value="/Kg">/kg</option>
                                                                    </select>   
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="nama">Deskripsi Barang</label>
                                                                <div class="input-group">
                                                                    <textarea name="deskripsi" class="form-control" placeholder="Masukkan Deskripsi" required></textarea>
                                                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                                                </div>
                                                            </div>
                                                            <div class="well well-sm"><strong><span class="glyphicon glyphicon-asterisk"></span> Tidak Boleh Kosong</strong></div>
                                                            <input type="submit" name="submitBarang" id="submit" value="Tambah Barang" class="btn btn-success pull-left">
                                                        </div>
                                                    </form>
                                                </div>
                                                <div class="modal-footer">

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end tambah -->
                                    <!-- /col-md-12 -->
                                    <!-- modal edit -->
                                    <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h2 class="modal-title" id="exampleModalLabel">Edit Profil</h2>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">

                                                </div>
                                                <div class="modal-footer">

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end edit -->
                                    <!-- modal edit -->
                                    <div class="modal fade" id="ModalEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h2 class="modal-title" id="exampleModalLabel">Edit Barang</h2>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">

                                                </div>
                                                <div class="modal-footer">

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end edit -->
                                </div>
                                <!-- /row -->
                            </div>
                            <!-- /tab-pane databarang -->
                            <!-- tab-pane riwayatbeli -->
                            <div id="riwayatbeli" class="tab-pane">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="content-panel">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th class="namaBarang">Nama Barang</th>
                                                        <th class="jumlahbarang">Jumlah Barang</th>
                                                        <th class="Total">Total Harga</th>
                                                        <th class="tanggal">Tanggal</th>
                                                        <th class="tools">Tools</th>
                                                    </tr>
                                                </thead>
                                                <?php 
                                                while ($show = mysqli_fetch_array($riwayatBeli)) {
                                                    $namaBarangnya = $show['NAMABARANG'];
                                                    ?>
                                                    <tbody>
                                                        <tr>
                                                            <td><?php echo $show['NAMABARANG'];?></td>
                                                            <td><?php echo $show['JUMLAHBARANG'];?></td>
                                                            <td>Rp. <?php echo $show['TOTALHARGA'];?></td>
                                                            <td><?php echo $show['TANGGAL'];?></td>
                                                            <td>
                                                                <a href="Proses/deleteRiwayat.php?IDBK=<?php echo $show['IDBK']?>" class="btn btn-danger btn-sm" onclick="return confirm('<?="Yakin Menghapus $namaBarangnya"?>')"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                                                            </td>
                                                        </tr>
                                                    <?php } ?>
                                                </tbody>
                                                <?php  while ($show = mysqli_fetch_array($jumlahBeli)) { ?>
                                                <tbody>
                                                    <tr>
                                                        <td> JUMLAH</td>
                                                        <td><?php echo $show['JUMLAHBARANG']?></td>
                                                        <td> Rp. <?php echo $show['TOTAL']?></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                <?php }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!-- /col-md-12 -->
                                </div>
                                <!-- /row -->
                            </div>
                            <!-- /tab-pane riwayatbeli -->
                            <!-- tab-pane konfirmasi -->
                            <div id="konfirmasi" class="tab-pane">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="content-panel">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th class="namapembeli"> Nama Pembeli</th>
                                                        <th class="namaBarang">Nama Barang</th>
                                                        <th class="jumlahbarang">Jumlah Barang</th>
                                                        <th class="Total">Total Harga</th>
                                                        <th class="tanggal">Tanggal</th>
                                                        <th class="status">Status</th>
                                                        <th class="tools">Tools</th>
                                                    </tr>
                                                </thead>
                                                <?php 
                                                while ($show = mysqli_fetch_array($dataKonfirmasi)) {
                                                    $barang = $show['NAMABARANG'];
                                                    ?>
                                                    <tbody>
                                                        <tr>
                                                            <td><?php echo $show['NAMAUSER']; ?></td>
                                                            <td><?php echo $show['NAMABARANG'];?></td> 
                                                            <td><?php echo $show['JUMLAHBARANG'];?></td>
                                                            <td>Rp. <?php echo $show['TOTALHARGA'];?></td>
                                                            <td><?php echo $show['TANGGALTRANSAKSI']; ?></td>
                                                            <td><?php echo $show['STATUS']; ?></td>
                                                            <td>
                                                                <?php 
                                                                if ($show['STATUS'] == 'Belum Dikonfirmasi') { ?>
                                                                    <a href="Proses/setuju.php?id=<?php echo $show['IDTRANSAKSI'];?>" class="btn btn-success btn-sm"  onclick="window.open('https://api.whatsapp.com/send?phone=<?php echo $show['NOHP'];?>&text=Barang%20<?php echo $show['NAMABARANG'];?>%20telah%20dikonfirmasi')">Ya</a>
                                                                    <a href="Proses/tidaksetuju.php?id=<?php echo $show['IDTRANSAKSI'];?>" class="btn btn-success btn-sm" onclick="window.open('https://api.whatsapp.com/send?phone=<?php echo $show['NOHP'];?>&text=Barang%20<?php echo $show['NAMABARANG'];?>%20tidak%20dikonfirmasi')">Tidak</a>
                                                                <?php }else{ ?>
                                                                    <a href="Proses/deteleKonfirmasi.php?ID=<?php echo $show['IDTRANSAKSI'];?>" class="btn btn-danger btn-sm" onclick="return confirm('<?="Yakin Menghapus $barang"?>')">Delete</a>
                                                                <?php   } ?>

                                                            </td>
                                                        </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>

                                        </div>
                                    </div>
                                    <!-- /col-md-12 -->
                                </div>
                                <!-- /row -->
                            </div>
                    
                                    <!-- /col-md-12 -->
                                </div>
                                <!-- /row -->
                            </div>
                        </div>
                        <!-- /tab-content -->
                    </div>
                    <!-- /panel-body -->
                </div>
                <!-- /col-lg-12 -->
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </section>
    <!-- /wrapper -->
</section>

<!-- /MAIN CONTENT -->
<!--main content end-->
<!--footer start-->
<footer class="site-footer">
    <div class="text-center">
        <p>
            &copy;  <strong>2019 TaniKu</strong>. All Rights Reserved
        </p>
        <div class="credits">
     </div>
<a href="profil.php" class="go-top">
    <i class="fa fa-angle-up"></i>
</a>
</div>
</footer>
<!--footer end-->
</section>
<!-- js placed at the end of the document so the pages load faster -->
<script src="profilcss/lib/jquery/jquery.min.js"></script>
<script src="profilcss/lib/bootstrap/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="profilcss/lib/jquery.dcjqaccordion.2.7.js"></script>
<script src="profilcss/lib/jquery.scrollTo.min.js"></script>
<script src="profilcss/lib/jquery.nicescroll.js" type="text/javascript"></script>
<!--common script for all pages-->
<script src="profilcss/lib/common-scripts.js"></script>
<!--script for this page-->
<!-- MAP SCRIPT - ALL CONFIGURATION IS PLACED HERE - VIEW OUR DOCUMENTATION FOR FURTHER INFORMATION -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyASm3CwaK9qtcZEWYa-iQwHaGi3gcosAJc&sensor=false"></script>
<script type="text/javascript">
CKEDITOR.replace('deskripsi',{height: 300} );</script>
</body>

</html>























<!-- <li>
                                <a data-toggle="tab" href="#PELANGGAN" >PELANGGAN</a>
                            </li> -->


   <!-- tab-pane PELANGGAN --><!-- 
                            <div id="PELANGGAN" class="tab-pane">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="content-panel">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th class="namaBarang">Nama Pembeli</th>
                                                        <th class="jumlahbarang">Jumlah Pembelian</th>
                                                    </tr>
                                                </thead>
                                                <?php 
                                                while ($show = mysqli_fetch_array($PELANGGAN)) {
                                                    ?>
                                                    <tbody>
                                                        <tr>
                                                            <td><?php echo $show['NAMAUSER'];?></td>
                                                            <td><?php echo $show['jumlah'];?></td>
                                                        </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!-- /col-md-12 -->
                                </div>
                                <!-- /row -->
                            </div> -->
                            <!-- /tab-pane PELANGGAN -->