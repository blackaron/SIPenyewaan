<?php
session_start();
if (!isset($_SESSION["username"])) {
	header("Location: login.php");
}
include "koneksi.php";

$editDataBarang = mysqli_query($mysqli, "SELECT * FROM BarangMasuk where IDBM='$_GET[IDBM]'");
while ($show = mysqli_fetch_array($editDataBarang)) {
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title></title>

		<link href="css/style.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container-fluid" style="padding-top: 50px; padding-bottom: 50px" >
			<div class="row">
				<h2>EDIT DATA BARANG</h2>
				<h3>ID : <?php echo $show['IDBM'];?></h3>
				<form action="Proses/updatesql.php?id=<?php echo $show['IDBM']?>" role="form" method="post" enctype="multipart/form-data">
					<div class="col-lg-12">
						<div class="form-group">
							<label for="gambar">Upload Gambar</label>
							<div class="input-group">
								<input name="gambar" type="file" class="form-control" value="<?php echo "<td><img src='Proses/gambar/".$show['GAMBAR']."' width='100' height='100'></td>";?>">
								<span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
							</div>
						</div>
						<div class="form-group">
							<label for="nama">Nama Barang</label>
							<div class="input-group">
								<input type="text" class="form-control" name="namabarang" placeholder="Masukkan Nama Barang" value="<?php echo $show['NAMABARANG'];?>">
								<span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
							</div>
						</div>
						<div class="form-group">
							<label for="nama">Harga Barang</label>
							<div class="input-group">
								<input type="text" class="form-control" name="hargabarang" placeholder="Masukkan Harga" value="<?php echo $show['HARGABARANG'];?>">
								<span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
							</div>
						</div>
						<div class="form-group">
							<label for="nama">Jumlah Barang</label>
							<div class="input-group">
								<input type="text" class="form-control" name="jmlbarang" placeholder="Masukkan Jumlah" value="<?php echo $show['JUMLAH'];?>">
								<span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
							</div>
						</div>
						<div class="form-group">
							<label for="nama">Satuan Barang</label>
							<div class="form-group">
								<select name="satuan" class="form-control" value="<?php echo $show['SATUAN'];?>">
									<option >--Pilih Satuan--</option>
									<option value="/Biji">/biji</option>
									<option value="/Ikat">/ikat</option>
									<option value="/Kg">/kg</option>
								</select>   
							</div>
						</div>
						<div class="form-group">
							<label for="nama">Deskripsi Barang</label>
							<div class="input-group">
								<textarea name="deskripsi" class="form-control"><?php echo $show['DESKRIPSI'];?></textarea>
								<span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
							</div>
						</div>
						<?php }?>
						<div class="well well-sm"><strong><span class="glyphicon glyphicon-asterisk"></span> Tidak Boleh Kosong</strong></div>
						<input type="submit" name="update" id="update" value="Edit Barang" class="btn btn-success pull-left">
						<a href="Profil.php" class="btn btn-success"> Batal</a>
					</form>
				</div>
			</div>

			<script src="js/jquery.min.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="js/scripts.js"></script>
			<script type="text/javascript">
				CKEDITOR.replace('deskripsi',{height: 300} );</script>
			</body>
			</html>