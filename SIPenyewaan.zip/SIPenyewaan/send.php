<?php
$nohp=$_POST['NO_HP'];
$kode=19877;
//isikan sesuai dengan keinginan anda, tapi jangan masukkan huruf. hanya digit angka.
// Script Kirim SMS Api Zenziva
$userkey="f06jkp"; // userkey lihat di zenziva
$passkey="s06m6160w8"; // set passkey di zenziva
$message="Silahkan masukkan kode $kode pada kolom verifikasi untuk melengkapi registrasi anda. terima kasih.";
// $url = "http://zenziva.com/apps/smsapi.php";
$url = "https://reguler.zenziva.net/apps/smsapi.php";
$curlHandle = curl_init();
curl_setopt($curlHandle, CURLOPT_URL, $url);
curl_setopt($curlHandle, CURLOPT_POSTFIELDS, 'userkey='.$userkey.'&passkey='.$passkey.'&nohp='.$nohp.'&pesan='.urlencode($message).$kode);
curl_setopt($curlHandle, CURLOPT_HEADER, 0);
curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curlHandle, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($curlHandle, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($curlHandle, CURLOPT_TIMEOUT,30);
curl_setopt($curlHandle, CURLOPT_POST, 1);
$results = curl_exec($curlHandle);
curl_close($curlHandle);

header("location: verifikasiOtp.php");



include "koneksi.php"; //memanggil file koneksi.php untuk menghubungkan ke database

if(isset($_POST['simpan'])){
  $username = $_POST['USERNAME'];
  $password = $_POST['PASSWORD'];
  $nama= $_POST['NAMA'];
  $alamat= $_POST['ALAMAT'];
  $nohp= $_POST['NO_HP'];
  $email= $_POST['EMAIL'];
   $gambar = $_FILES['GAMBAR_USER']['name'];
  $lokasi_file = $_FILES['GAMBAR_USER']['tmp_name'];

    $path = "img/".$gambar;

    move_uploaded_file($lokasi_file, $path);


  // // menambahkan query sql tambah data untuk menambahkan untuk data ke database
  $data = mysqli_query($koneksi,"INSERT INTO user set USERNAME='$username', password='$password', NAMA='$nama',NO_HP='$nohp', ALAMAT= '$alamat',EMAIL='$email', level=2, GAMBAR_USER ='$gambar'") or die ("data salah : ".mysqli_error($koneksi));

  // untuk mengetahui apakah data berhasil disimpan atau belum
  if ($data) {
    echo "<script>alert('Pendaftaran Berhasil');window.location='login.php?hal=login';</script>";
  }else{
    echo "<script>alert('Pendaftaran Gagal');window.location='registerUser.php?hal=login';</script>";
    
  }
  

}

?>
