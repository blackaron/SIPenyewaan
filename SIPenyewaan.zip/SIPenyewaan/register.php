<!-- <?php
if (isset($_POST['submit'])) {
  include('koneksi.php');
  session_start();
 
    $idu  = $_GET['ID_USER'];
    $nama = $_POST['NAMA'];
    $alamat = $_POST['ALAMAT'];
    $nohp= $_POST['NO_HP'];
    $email= $_POST['EMAIL'];
    $username = $_POST['USERNAME'];
    $password = $_POST['PASSWORD'];

//QUERY MEMASUKAN DATA KE TABEL USER
        $data = mysqli_query($koneksi, "INSERT INTO user SET NAMA='$nama', ALAMAT='$alamat' , NO_HP='$nohp' , EMAIL='$email', USERNAME='$username', PASSWORD='$password' ") or die ("data salah: ".mysqli_error($koneksi));
        
        //untuk mengetahui apakah data berhasil disimpan atau belum
        if ($data) {
        	$_SESSION['username'] = $username;
            header("Location: index.php");// untuk kembali ke halaman tampil.php
        } else {
            echo "Gagal Input Data!!!";
            echo "<br> <a href='index.php'> KEMBALI </a>"; // untuk kembali ke halaman tampil.php
        }
  } 
?>   -->


<?php
session_start();
?>


<!doctype html>
<html lang="en" class="fullscreen-bg">

<head>
  <title>Login | Klorofil - Free Bootstrap Dashboard Template</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <!-- VENDOR CSS -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="assets/vendor/linearicons/style.css">
  <!-- MAIN CSS -->
  <link rel="stylesheet" href="assets/css/main.css">
  <!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
  <link rel="stylesheet" href="assets/css/demo.css">
  <!-- GOOGLE FONTS -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
  <!-- ICONS -->
  <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
  <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
</head>

<body>
  <!-- WRAPPER -->
  <div id="wrapper">
    <div class="vertical-align-wrap">
      <div class="vertical-align-middle">
        <div class="auth-box ">
          <div class="left">
            <div class="content">
              <div class="header">
                <div class="logo text-top"><img src="assets/img/logo.png" alt="Klorofil Logo"></div>
                <p class="login">Register</p>
              </div> 

              <form class="form-auth-small" action="send.php" method= "post" >
                <div class="form-group">
                  <label for="signin-username" class="control-label sr-only">Username</label>
                  <input name="USERNAME" type="text" class="form-control" required="" id="signin-username" value="" placeholder="Username">
                </div>
                <div class="form-group">
                  <label for="signin-password" class="control-label sr-only">Password</label>
                  <input type="PASSWORD" name="PASSWORD" class="form-control" required="" id="signin-password" value="" placeholder="Password">
                </div>
                <div class="form-group">
                  <label for="signin-username" class="control-label sr-only">Nama</label>
                  <input name="NAMA" type="text" class="form-control" id="signin-username" required="" value="" placeholder="Nama Lengkap">
                </div>
                
                <div class="form-group">
                  <label for="signin-address" class="control-label sr-only">Alamat</label>
                  <input name="ALAMAT" type="text" class="form-control" required="" id="signin-address" value="" placeholder="Alamat">
                </div>
                <div class="form-group">
                  <label for="signin-username" class="control-label sr-only">No Telepon</label>
                  <input name="NO_HP" type="number" class="form-control" required="" id="signin-telephone" value="" placeholder="No Telepon">
                </div>
                <div class="form-group">
                  <label for="signin-email" class="control-label sr-only">Email</label>
                  <input name="EMAIL" type="email" class="form-control" id="signin-email" value="" placeholder="Email">
                </div>
                 <div class="form-group">
                  <label class="control-label sr-only">Upload File:</label>
                  <input name="GAMBAR_USER" type="file" class="form-control" id="file" value="" placeholder="KTP/SIM">
                </div>

                  
            <input type="submit" name="simpan" class="btn btn-primary" value="DAFTAR" />
            <button type="reset" name="batal"  value="batal" class="btn btn-danger">Batal <span class="glyphicon glyphicon-remove"></button></a>
               <div class="button">
                  
                </div>

              </form>
             
            </div>
          </div>
          <div class="right">
            <div class="overlay"></div>
            <div class="content text" >
              <h1 class="heading" ></h1>
              <p></p>
            </div>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>

  </div>
  <!-- END WRAPPER -->
</body>

</html>
<?php

include "koneksi.php"; //memanggil file koneksi.php untuk menghubungkan ke database

if(isset($_POST['simpan'])){
  $username = $_POST['USERNAME'];
  $password = $_POST['PASSWORD'];
  $nama= $_POST['NAMA'];
  $alamat= $_POST['ALAMAT'];
  $nohp= $_POST['NO_HP'];
  $email= $_POST['EMAIL'];
   $gambar = $_FILES['GAMBAR_USER']['name'];
  $lokasi_file = $_FILES['GAMBAR_USER']['tmp_name'];

    $path = "img/".$gambar;

    move_uploaded_file($lokasi_file, $path);


  // // menambahkan query sql tambah data untuk menambahkan untuk data ke database
  $data = mysqli_query($koneksi,"INSERT INTO user set USERNAME='$username', password='$password', NAMA='$nama',NO_HP='$nohp', EMAIL='$email', level=2, GAMBAR_USER ='$gambar'") or die ("data salah : ".mysqli_error($koneksi));

  // untuk mengetahui apakah data berhasil disimpan atau belum
  if ($data) {
    echo "<script>alert('Pendaftaran Berhasil');window.location='login.php?hal=login';</script>";
  }else{
    echo "<script>alert('Pendaftaran Gagal');window.location='registerUser.php?hal=login';</script>";
    
  }
  

}

?>