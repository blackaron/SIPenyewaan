<?php
include 'koneksi.php'; 
include 'navbar.php';
session_start();


$show = mysqli_query($koneksi, "SELECT * FROM user  WHERE ID_USER ='$id_user'");

?>


<!doctype html>
<html lang="en">

<head>
	<title>Profile | Klorofil - Free Bootstrap Dashboard Template</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/vendor/linearicons/style.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
	<link rel="stylesheet" href="assets/css/demo.css">
	<!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<!-- ICONS -->
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						<li><a href="index.php" class="active"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
						<li><a href="dataAdmin.php" class=""><i class="lnr lnr-user"></i> <span>Data Admin</span></a></li>
						<li><a href="dataUser.php" class=""><i class="lnr lnr-user"></i> <span>Data User</span></a></li>
						<li><a href="dataBarang.php" class=""><i class="lnr lnr-pencil"></i> <span>Data Barang</span></a></li>
						<li><a href="dataKategori.php" class=""><i class="lnr lnr-pencil"></i> <span>Data Kategori</span></a></li>
						<li><a href="dataSewa.php" class=""><i class="lnr lnr-pencil"></i> <span>Data Sewa</span></a></li>
						<li><a href="dataPengembalian.php" class=""><i class="lnr lnr-pencil"></i> <span>Data Pengembalian</span></a></li>

					</ul>
				</nav>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="panel panel-profile">
						<div class="clearfix">
							<!-- LEFT COLUMN -->
							<div class="profile-center">
								<!-- PROFILE HEADER -->
								<div class="profile-header">
									<div class="overlay"></div>
									<div class="profile-main">
										<img src="img/<?php echo $datashow['GAMBAR_USER']; ?>" class="img-circle" alt="Avatar">
										<h3 class="name"></h3>
									</div>
								</div>

								<!-- PROFILE DETAIL -->
								<div class="profile-detail">
									<div class="profile-info">
										<h4 class="heading">Basic Info</h4>
										<ul class="list-unstyled list-justify">
									<!-- <?php
										$user = mysqli_query($koneksi, "SELECT * FROM user ");
										while ($show = mysqli_fetch_array($user)) {
									?>
										<tbody>
										<?php } ?>	

											<li>Nama</li>
											<span><?php echo $show['NAMA'];?></span>
											<li>Alamat</li>
											<span><?php echo $show['ALAMAT'];?></span>
											<li>No Hp </li>
											<span><?php echo $show['NO_HP'];?></span>
											<li>Email</li>
											<span><?php echo $show['EMAIL'];?></span>
											 -->

<thead>
											
										</thead>
										<tbody>
											<?php
											$user = mysqli_query($koneksi, "SELECT * FROM user where ID_USER = 1");
											while ($show = mysqli_fetch_array($user)) {
											?>
											<tr>
												<li>ID<span><?php echo $show['ID_USER']; ?></span></li>
												<li>Nama <span><?php echo $show['NAMA']; ?></span></li>
												<li>Alamat<span><?php echo $show['ALAMAT'];?></span></li>
												<li>No Hp<span><?php echo $show['NO_HP'];?></span></li>
												<li>Email<span><?php echo $show['EMAIL'];?></span></li>
											
											</tr>									
										</ul>	
									</tbody>

									</div>
									
									<div class="profile-info">
										<h4 class="heading">About</h4>
										<p>Interactively fashion excellent information after distinctive outsourcing.</p>
									</div>

									<div class="text-center"><a href="editUser.php?ID_USER=<?php echo $show['ID_USER'];?>" class="btn btn-primary">Edit Profile</a></div>
									<?php } ?>
								</div>

								<!-- END PROFILE DETAIL -->
								
							</div>
							<!-- END LEFT COLUMN -->
							
						
						</div>
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>
			<div class="container-fluid">
				<p class="copyright">&copy; 2017 <a href="https://www.themeineed.com" target="_blank">Theme I Need</a>. All Rights Reserved.</p>
			</div>
		</footer>
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>
</body>

</html>
