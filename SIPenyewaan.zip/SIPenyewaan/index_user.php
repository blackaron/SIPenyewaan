
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="html 5 template">
	<meta name="author" content="tonytemplates.com">
<!-- 	<link rel="icon" href="favicon.ico"> -->
	<title>Ciliwung Camp</title>
	<!-- Bootstrap core CSS -->
	<link href="assetss/css/plugins/bootstrap.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/jquery.smartmenus.bootstrap.css" rel="stylesheet">
	<link href="assetss/css/plugins/nivo-slider.css" rel="stylesheet">
	<link href="assetss/css/plugins/swiper.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/intlTelInput.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/remodal.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/animate.css" rel="stylesheet">
	<link href="assetss/css/main-style.css" rel="stylesheet">
	<link href="iconfont/style.css" rel="stylesheet">
	<!-- Google Fonts -->
	<link href="#" rel="stylesheet">
</head>


<body class="page__home">
<?php
	require_once('header.php');
?>

	<!-- // Header -->
	<!-- Content  -->
	<main id="page-content">
		<div class="parallax_box">
			<?php
				require_once('hal.php');
			?>
		</div>
	</main>
	<!-- // Content  -->
	<!-- Footer -->
	<footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <div class="row">
              <div class="col-md-5">
                <h2 class="footer-heading mb-4">About Us</h2>
                <p>CV. Ciliwung Camp.<br>
                Jl. Ciliwung I No.76, Purwantoro, Kec. Blimbing, Kota Malang, Jawa Timur 65126</p>
              </div>
              <div class="col-md-3 mx-auto">
                <h2 class="footer-heading mb-4">Quick Links</h2>
                <ul class="list-unstyled">
                  <li><a href="#">About Us</a></li>
                  <li><a href="#">Services</a></li>
                  <li><a href="#">Testimonials</a></li>
                  <li><a href="#">Contact Us</a></li>
                </ul>
              </div>
              
            </div>
          </div>
          <div class="">
              <h2 class="footer-heading mb-4">Follow Us</h2>
                <a href="#" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
            </div>
 
          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <div class="border-top pt-5">
            <p class="copyright">
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
            </div>
          </div>
          
        </div>
      </div>


	</footer>
	<!-- //Footer -->
	<!-- Google map -->
	<script src="assetss/js/jquery.1.12.4.min.js"></script>
	<script src="assetss/js/plugins/bootstrap.min.js"></script>
	<script src="assetss/js/plugins/wow.min.js"></script>
	<script src="assetss/js/plugins/jquery.smartmenus.min.js"></script>
	<script src="assetss/js/plugins/jquery.smartmenus.bootstrap.js"></script>
	<script src="assetss/js/plugins/jquery.nivo.slider.js"></script>
	<script src="assetss/js/plugins/swiper.min.js"></script>
	<script src="assetss/js/plugins/intlTelInput.min.js"></script>
	<script src="assetss/js/plugins/remodal.js"></script>
	<script src="assetss/js/plugins/stickup.min.js"></script>
	<script src="assetss/js/plugins/tool.js"></script>
	<script src="assetss/js/custom.js"></script>
</body>

</html>