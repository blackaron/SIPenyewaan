<?php
require_once('header.php');
include "koneksi.php";

session_start();

// $username = $_SESSION['USERNAME'];
// $user = mysqli_query($koneksi,"SELECT * FROM user where USERNAME='$username'");
// $showuser = mysqli_fetch_array($user);

// $barang = mysqli_query($koneksi,"SELECT * FROM barang where ID_BARANG='$_GET[NAMA_BARANG]'");
// $show = mysqli_fetch_array($barang);
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Warehouse &mdash; Website Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,900|Oswald:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  
  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   

    
    <div class="site-blocks-cover inner-page-cover overlay" style="background-image: url(img/b.jpg);" data-aos="fade">
      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-5 mx-auto mt-lg-5 text-center">
            <h1>Riwayat pemesanan</h1>
            
          </div>
        </div>
      </div>

      <a href="#property-details" class="smoothscroll arrow-down"><span class="icon-arrow_downward"></span></a>
    </div>  

     <div class="comment-form-wrap pt-5">
                <center><h3 class="mb-5">Riwayat</h3></center>
<div class="col-md-12">
    <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
              <thead>
               <th class="text-center">ID Reservasi</th>
        <th class="text-center">Nama User</th>
        <th class="text-center">Nama Barang</th>
        <th class="text-center">Tanggal Reservasi</th>
        <th class="text-center">Tanggal Pinjam</th>
        <th class="text-center">Tanggal Kembali</th>
        <th class="text-center">Jumlah Barang</th>
        <th class="text-center">Jarak</th>
        <th class="text-center">Total Harga</th>
       
        <th class="text-center">Status</th>
    </tr>
    </thead>
    <tbody>
        <?php
        $ambilUser = $_SESSION["USERNAME"]; 
                $tampil = mysqli_query($koneksi, "SELECT * FROM USER WHERE USERNAME='$ambilUser'");
                // $showuser = mysqli_fetch_array($tampil);
               
                          if($tampil->num_rows>0){
                            while($data = $tampil->fetch_object()){  
                                $tampilId = $data->ID_USER;
                           }}       


           $reservasi = mysqli_query($koneksi,"SELECT r.*, us.*, br.* FROM reservasi as r inner join user as us on r.id_user = us.id_user inner JOIN Barang AS br on r.id_barang = br.id_barang where r.ID_USER = '$tampilId'");
           
            if($reservasi->num_rows>0){
                            while($data = $reservasi->fetch_object()){  
                               
                           
                  ?>
<!-- 
                  <?php
                   $barang = mysqli_query($koneksi,"SELECT * FROM barang where NAMA_BARANG='$NAMA_BARANG'");
                   $show = mysqli_fetch_array($barang);
                   if($barang->num_rows>0){
                            while($data = $barang->fetch_object()){  
                                $show = $data->NAMA_BARANG;
                           }} 
                        ?> -->
                     
                        <tr>
                          <td class='text-center' width='50px'><?php echo $data->ID_RESERVASI?></td> 
                         <!--  <td class='text-center'><?php echo $showuser['NAMA'] ?></td> -->
                          <!-- <td class='text-center' ><?php echo $show['NAMA_BARANG']?></td>  -->
                          
                          <!-- <td class='text-center'><?php echo $showuser['NAMA'] ?></td> -->

                          <!-- <p><?php echo $showuser['NAMA'] ?></p></td> -->
                    <!-- <input type="hidden" name="ID_USER" required="" value="<?php echo $showuser['ID_USER'] ?>">

                          <td class='text-center'><?php echo $show['NAMA_BARANG'] ?></td>
                 
                    <input type="hidden" class="form-control" name="ID_BARANG" required="" value="<?php echo $show['ID_BARANG'] ?>"> -->


                          <td class='text-center'><?php echo $data->NAMA?></td>
                          <td class='text-center'><?php echo $data->NAMA_BARANG?></td>
                          <td class='text-center'><?php echo $data->TGL_RESERVASI?></td>
                          <td class='text-center'><?php echo $data->TGL_PINJAM?></td>
                          <td class='text-center'><?php echo $data->TGL_KEMBALI?></td>
                          <td class='text-center'><?php echo $data->JUMLAH_SEWA?></td>
                          <td class='text-center'><?php echo $data->JARAK?></td>
                          <td class='text-center'><?php echo $data->TOTAL_HARGA?></td>
                          
                           <td class='text-center'><?php echo $data->STATUS?></td>

                          <?php 
                            if($data->STATUS == 'Menunggu Konfirmasi'){
                              ?>
                              <td class='text-center'><?php echo $data->STATUS?></td>
                              <?php
                            }elseif ($data->STATUS == 'KONFIRMASI BARANG') {
                           ?>
                            <td>
                            <a href="buktitransfer2.php?ID_RESERVASI=<?php echo $data->ID_RESERVASI?>">Konfirmasi Pembayaran</a>
                          </td>
                           <?php
                            }elseif ($data->STATUS == 'MENUNGGU KONFIRMASI PEMBAYARAN') {
                              ?>
                               <td class='text-center'><?php echo $data->STATUS?></td>
                              <?php
                            }elseif ($data->STATUS == 'ORDER AKAN DIPROSES') {
                              ?>
                              <?php
                               }elseif ($data->STATUS == 'Sudah Kembali') {
                              ?>
                               <td class='text-center'><?php echo $data->STATUS?></td>
                              <?php
}
                          ?>
                        </tr>
                        <?php 
                                            ;
                                                 
                                               }
                                              }else{
                                                echo "<tr><td colspan='9'>Data Kosong</td></tr>";
                                              }
                                          ?>
              </tbody>
            </table>
          </div>
        </div>

    
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <div class="row">
              <div class="col-md-5">
                <h2 class="footer-heading mb-4">About Us</h2>
                <p>CV. CiliwungCamp Nusantara.<br>
                Jl. Ciliwung I No.76, Purwantoro, Kec. Blimbing, Kota Malang, Jawa Timur 65126.<br>
              0851-0396-5552</p>
              </div>
              <!-- <div class="col-md-3 mx-auto">
                <h2 class="footer-heading mb-4">Quick Links</h2>
                <ul class="list-unstyled">
                  <li><a href="#">About Us</a></li>
                  <li><a href="#">Services</a></li>
                  <li><a href="#">Testimonials</a></li>
                  <li><a href="#">Contact Us</a></li>
                </ul>
              </div> -->
              
            </div>
          </div>
          <!-- <div class="col-md-4">
            <div class="mb-4">
              <h2 class="footer-heading mb-4">Subscribe Newsletter</h2>
            <form action="#" method="post" class="footer-subscribe">
              <div class="input-group mb-3">
                <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="button-addon2">
                <div class="input-group-append">
                  <button class="btn btn-primary text-black" type="button" id="button-addon2">Send</button>
                </div>
              </div>
            </form>  
            </div> -->
            
            <div class="">
              <h2 class="footer-heading mb-4">Follow Us</h2>
                <a href="https://www.facebook.com/CiliwungCampOutdoorService/" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                <a href="https://twitter.com/ciliwungcamp/status/550520866770264064?lang=ar" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                <a href="https://www.instagram.com/ciliwungcamp/?hl=id" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                <!-- <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a> -->
            </div>
 
          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <div class="border-top pt-5">
            <p class="copyright">
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
            </div>
          </div>
          
        </div>
      </div>
    </footer>

  </div> <!-- .site-wrap -->

  </div> <!-- .site-wrap -->

  <a href="#top" class="gototop"><span class="icon-angle-double-up"></span></a> 

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>

  
  <script src="js/main.js"></script>
    
  </body>
</html>