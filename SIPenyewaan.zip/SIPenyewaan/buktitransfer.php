<?php
include 'koneksi.php';
include 'header.php';
session_start();

$idreservasi = $_GET['ID_RESERVASI'];
echo($idreservasi);

$data = mysqli_query($koneksi, "SELECT TOTAL_HARGA FROM reservasi WHERE ID_RESERVASI='$idreservasi'");
while ($show = mysqli_fetch_array($data)) {
	echo $show['TOTAL_HARGA'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="html 5 template">
	<meta name="author" content="tonytemplates.com">
	<!-- 	<link rel="icon" href="favicon.ico"> -->
	<title>Ciliwung Camp</title>
	<!-- Bootstrap core CSS -->
	<link href="assetss/css/plugins/bootstrap.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/jquery.smartmenus.bootstrap.css" rel="stylesheet">
	<link href="assetss/css/plugins/nivo-slider.css" rel="stylesheet">
	<link href="assetss/css/plugins/swiper.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/intlTelInput.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/remodal.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/animate.css" rel="stylesheet">
	<link href="assetss/css/main-style.css" rel="stylesheet">
	<link href="iconfont/style.css" rel="stylesheet">
	<!-- Google Fonts -->
	<link href="#" rel="stylesheet">
</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
			<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
				<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3>Transfer ke rekening BNI A.N Ciliwung Camp No Rek. 12345678</h3>
					<h3 class="page-title">Transaksi</h3>

						<div class="row">
						<div class="col-md-12">
							<!-- BORDERED TABLE -->
							<div class="panel">
								<div class="panel-heading">

									<h3 class="panel-title">Bukti Transfer</h3>
									
								</div>
								<div class="panel-body">
									<table class="table table-bordered table-hover">
								<form action="buktitransfersql.php?ID_RESERVASI=<?php echo $idreservasi ?>" method="POST" enctype="multipart/form-data">
									
									 <tr> 
						                <td>Nama Pengirim</td>
						                <td><input type="text" name="NAMA_PENGIRIM" required="" placeholder=""></td>
						           		</tr>
				
						            <tr> 
						                <td>Nama Bank</td>
						                <td><input type="text" name="ASAL_BANK" required="" placeholder=""></td>
						            </tr>
						            <tr> 
						                <td>Tanggal Transfer</td>
						                <td><?php echo date("Y/m/d");?></td>
						            </tr>
						            <tr> 
						                <td>Jumlah Bayar</td>
						                <td><?php echo $show['TOTAL_HARGA']?></td>
						            </tr>
						            <tr>
						            <td><img src="img/<?php echo $datashow['BUKTI_BAYAR']; ?>" 
						            	width="175px" height="175px"></td> 
										<th width="200" scope="row">Edit Gambar : <input type="file" name="BUKTI_BAYAR"></th></p>
						            <tr>
						                <td><button type="submit" name ="simpan" value="simpan" class="btn btn-primary">Simpan <span class="glyphicon glyphicon-ok"></span></button>
										<button type="reset" name="batal"  value="batal" class="btn btn-danger">Batal <span class="glyphicon glyphicon-remove"></span></button></td>
						            </tr>     
											   
											</tr>
										</tbody>
									</table>	
								</div>

							</div>
							<!-- END BORDERED TABLE -->
						</div>
							<!-- END BORDERED TABLE -->
						</div>
		<!-- END MAIN -->
		<!-- Footer -->
		<footer class="site-footer">
			<section  class="box-elements">
				<div class="container">
					<div class="row">
					<!-- <div class="col-xs-12 col-sm-6 col-md-12 col-lg-3">
						<figure class="footer_logo"><a href="#"><span><em>Ciliwung</em><strong>Camp</strong></span><i class="icon-111"></i></a></figure>
					</div> -->
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<h5>Perusahaan</h5>
						<ul class="footer-list">
							<li><a href="#">Beranda</a></li>
							<li><a href="#">Login</a></li>
							<li><a href="#">Produk</a></li>
							<li><a href="#">Kontak</a></li>
						</ul>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<h5>Customer Services</h5>
						<ul class="footer-list">
							<li><a href="#">Blog</a></li>
							<li><a href="#">FAQs</a></li>
							<li><a href="#">Help renting a product</a></li>
							<li><a href="#">Terms and Conditions</a></li>
						</ul>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<div class="contact-info">
							<span class="phone_number"><i class="icon-telephone"></i> 0822-3320-3907</span>
							
							<span class="location_info">
								<i class="icon-placeholder-for-map"></i>
								<em>Alamat Perusahaan</em> 
								<em>Ciliwung Camp</em> 
								<em>Jl. Ciliwung I No.76, Purwantoro, Kec. Blimbing, Kota Malang, Jawa Timur 65126</em> </span>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section class="site-footer__bottom-panel">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-md-6">
							<div class="copyright">&copy; 2019 | <a href="#">Created By</a> | <a href="#">State Polytechnic of Malang </a></div>
						</div>
						<div class="col-xs-12 col-md-6"> 
							<div class="social-list">
								<ul class="social-list__icons">
									<li><a href="#"><i class="icon-facebook-logo"></i></a></li>
									<li><a href="#"><i class="icon-twitter-letter-logo"></i></a></li>
									<li><a href="#"><i class="icon-google-plus"></i></a></li>
									<li><a href="#"><i class="icon-linkedin-logo"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</section>

			<a href="#" class="scrollup"><i class="icon-arrow-down-sign-to-navigate"></i></a>

		</footer>
		<!-- //Footer -->
		<!-- Google map -->
		<script src="assetss/js/jquery.1.12.4.min.js"></script>
		<script src="assetss/js/plugins/bootstrap.min.js"></script>
		<script src="assetss/js/plugins/wow.min.js"></script>
		<script src="assetss/js/plugins/jquery.smartmenus.min.js"></script>
		<script src="assetss/js/plugins/jquery.smartmenus.bootstrap.js"></script>
		<script src="assetss/js/plugins/jquery.nivo.slider.js"></script>
		<script src="assetss/js/plugins/swiper.min.js"></script>
		<script src="assetss/js/plugins/intlTelInput.min.js"></script>
		<script src="assetss/js/plugins/remodal.js"></script>
		<script src="assetss/js/plugins/stickup.min.js"></script>
		<script src="assetss/js/plugins/tool.js"></script>
		<script src="assetss/js/custom.js"></script>
	</body>

</html>
