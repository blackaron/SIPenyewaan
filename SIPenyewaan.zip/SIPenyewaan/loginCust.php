<?php 
	include 'koneksi.php';
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="html 5 template">
	<meta name="author" content="tonytemplates.com">
	<link rel="icon" href="favicon.ico">
	<title>Ciliwung Camp</title>
	<link href="assetss/css/plugins/bootstrap.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/jquery.smartmenus.bootstrap.css" rel="stylesheet">
	<link href="assetss/css/plugins/nivo-slider.css" rel="stylesheet">
	<link href="assetss/css/plugins/swiper.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/intlTelInput.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/remodal.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/animate.css" rel="stylesheet">
	<link href="assetss/css/main-style.css" rel="stylesheet">
	<link href="iconfont/style.css" rel="stylesheet">
</head>

<body class="page__home">
<div class="plash">
	<div id="scene">
		<span></span>
		<div id="road">
			<div id="stripes"></div>
		</div>
	</div>
	<div class="loading">Loading<span>...</span></div>
</div>
	<main id="page-content">
		<div class="container">
			<div class="row">
				<div class="col-xs-6">
					<form action="loginCust_act.php?act=1" class="order-details-form" name="" method="post" novalidate>
						<div class="inner-form">
						<h3>LOGIN</h3>
										<div >
											<input type="text" name="username" placeholder="Username" required="" style="width: 50%">
										</div>
										<div cl>
											<input type="password" name="password" placeholder="Password" required="" style="width: 50%">
										</div>
										<br>
							<button type="submit" class="btn">Login</button>
						</div>
					</form>
				</div>
				<div class="col-xs-6">
					<form action="#" class="order-details-form" name="" method="post" novalidate>
						<div class="inner-form" >
						<h3>Daftar</h3>
										<div cl>
											<input type="text" name="nama_cs" placeholder="Nama Lengkap" style="text-align: center;width: 80%" required="">
										</div>
										<div >
											<input type="text" name="alamat_cs" placeholder="Alamat" required="" style="text-align: center;width: 80%">
										</div>
										<div >
											<input type="text" name="telp_cs" placeholder="No. Telepon" required="" style="text-align: center;width: 80%">
										</div>
										<div >
											<input type="text" name="username_cs" placeholder="Username" required="" style="text-align: center;width: 80%">
										</div>
										<div >
											<input type="password" name="password_cs" placeholder="Password" required="" style="text-align: center;width: 80%">
										</div>
										
										<br>
							<button type="submit" class="btn" name="daftar" value="Lanjut">DAFTAR</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</main>
	
	<script src="assetss/js/jquery.1.12.4.min.js"></script>
	<script src="assetss/js/plugins/bootstrap.min.js"></script>
	<script src="assetss/js/plugins/wow.min.js"></script>
	<script src="assetss/js/plugins/jquery.smartmenus.min.js"></script>
	<script src="assetss/js/plugins/jquery.smartmenus.bootstrap.js"></script>
	<script src="assetss/js/plugins/jquery.nivo.slider.js"></script>
	<script src="assetss/js/plugins/swiper.min.js"></script>
	<script src="assetss/js/plugins/intlTelInput.min.js"></script>
	<script src="assetss/js/plugins/remodal.js"></script>
	<script src="assetss/js/plugins/stickup.min.js"></script>
	<script src="assetss/js/plugins/tool.js"></script>
	<script src="assetss/js/custom.js"></script>
</body>
</html>

<?PHP
if (isset($_POST['daftar'])) {
  
  $NAMA			=$_POST['nama_cs'];
  $ALAMAT		=$_POST['alamat_cs'];
  $NO_HP			=$_POST['telp_cs'];
  $EMAIL		=$_POST['username_cs'];
  $PASSWORD		=md5 ($_POST['password_cs']);
  // $cek = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM user WHERE EMAIL='".$EMAIL."'"));
  //             if ($cek > 0){
  //               echo "<script>alert('Username sudah ada !');window.location='index.php?hal=login'</script>";
  //             }else{
  $querymasuk="INSERT INTO user(NAMA, ALAMAT, NO_HP, EMAIL, PASSWORD) VALUE ('$NAMA', '$ALAMAT', '$NO_HP', '$EMAIL', '$PASSWORD')";
  $masuk=$koneksi->query($querymasuk);
  if($masuk){
    echo "<script>alert('Anda Berhasil Daftar !');window.location='index.php?hal=login'</script>";
    echo"<script>alert ('Selamat datang ".$NAMA."');
	                   window.location='index.php?page=home'</script>";
  }

// }
    }
?>