<?php
include "koneksi.php";
include "header.php";

session_start();
if(!isset($_SESSION['USERNAME']) ){
	echo"<script>window.alert('maaf anda harus login terlebih dahulu')</script>";
	echo"<script>window.location=('index.php')</script>";
	exit();
}
include "koneksi.php";

$username = $_SESSION['USERNAME'];
$user = mysqli_query($koneksi,"SELECT * FROM user where USERNAME='$username'");
$showuser = mysqli_fetch_array($user);

$barang = mysqli_query($koneksi,"SELECT * FROM barang where ID_BARANG='$_GET[ID_BARANG]'");
$show = mysqli_fetch_array($barang);
// $barang1 = mysqli_query($koneksi,"SELECT * FROM reservasi where ID_RESERVASI ='$_POST[ID_RESERVASI]'");

// $show1 = mysqli_fetch_array($barang1);
?>


<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="html 5 template">
	<meta name="author" content="tonytemplates.com">
	<!-- 	<link rel="icon" href="favicon.ico"> -->
	<title>Ciliwung Camp</title>
	<!-- Bootstrap core CSS -->
	<link href="assetss/css/plugins/bootstrap.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/jquery.smartmenus.bootstrap.css" rel="stylesheet">
	<link href="assetss/css/plugins/nivo-slider.css" rel="stylesheet">
	<link href="assetss/css/plugins/swiper.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/intlTelInput.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/remodal.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/animate.css" rel="stylesheet">
	<link href="assetss/css/main-style.css" rel="stylesheet">
	<link href="iconfont/style.css" rel="stylesheet">
	<!-- Google Fonts -->
	<link href="#" rel="stylesheet">
</head>

<body>
	<!-- MAIN -->
	<div class="container">
		<div class="row">
			
			<div class="panel-heading">
				<h3 class="panel-title">Data Barang</h3>

			</div>


			<form action="isiformsewasql.php" method="POST" enctype="multipart/form-data">
				<table width="500" border="5" align="center">
					<div class="container">
						<table class="table table-striped">
						</tr>

						<input type="hidden" name="id_pinjam" required="" value="">
<!-- 				<tr class="info">
					<th scope="row">Id Pinjam </th>
					<td><input type="hidden" name="id_pinjam" required="" value=""></td>
				</tr> -->
				</tr>
			<tr>
				<th scope="row">Tanggal Reservasi</th>
				<td><p><?php echo date("Y/m/d h:i:s");?></p></td>
				<!-- <td> <?php echo date("Y/m/d") . "<br>"; ?></td> -->
				
			</tr>
			</tr>
			<tr>
				<th scope="row">Tanggal Pinjam</th>
				<td><input type="date" name="TGL_PINJAM" required="" placeholder="Tanggal Pinjam"></td>
			</tr>
			<tr>
				<th scope="row">Tanggal Kembali</th>
				<td><input type="date" name="TGL_KEMBALI" required="" placeholder="Tanggal Kembali"></td>
			</tr>
			<tr>
				<th scope="row">Nama</th>
				<td><input type="text" name="NAMA" required="" value="<?php echo $showuser['NAMA'] ?>"></td>
			</tr>
			<tr>
				<th scope="row">id Barang</th>
				<td><input type="text" name="NAMA_BARANG" required="" value="<?php echo $show['NAMA_BARANG'] ?>"></td>

				<td><input type="hidden" name="HARGA_SEWA"value="<?php echo $show['HARGA_SEWA']?>" ></td>
			</tr>
			<tr>
				<th scope="row">Jumlah Barang </th>
				<td><input type="number" name="JUMLAH_SEWA" required="" min=1 max="<?php echo $show['JUMLAH_SEWA'] ?>" ></td>
				<td><input type="hidden" name="JUMLAH_STOK"value="<?php echo $show['STOK']?>" ></td>
			</tr>
			<!-- <tr class="info">
				<th scope="row">Total Harga </th>
				<td><input type="text" name="TOTAL_HARGA" required="" required="" value="<?php echo $show1['TOTAL_HARGA'] ?>"></td>
			</tr> -->

			<tr>
				<th scope="row">Jaminan</th>
				<td>
					<select name="JAMINAN">  
						<option value="">Silahkan Pilih</option>  
						<option value="KTP">KTP</option>  
						<option value="SIM">SIM</option>
						<option value="KTM">KTM</option>     
					</select>   
				</td>
			</tr>
			<tr>
				<th scope="row">No Identitas</th>
				<td><input type="text" name="NO_IDENTITAS" required="" ></td>
			</tr>
			<tr>
				<th scope="row">Metode Pengambilan Alat</th>
				<td>
					<select name="METODE_PENGAMBILAN">  
						<option value="">Silahkan Pilih</option>  
						<option value="KTP">Ambil Ke Toko</option>  
						<option value="SIM">Dikirim Ke Alamat Pengiriman</option>   
					</select>   
				</td>
			</tr>
			<th scope="row"><b>Alamat Pengiriman</b></th>
			<td><textarea name="ALAMAT_KIRIM" required=""  class="form-control"></textarea></td>
		</tr>
	</tr>
	<!-- <tr class="info">
		<th scope="row">Total Pembayaran </th>
		<td><input type="text" name="TOTAL_SEWA" required=""  value="<?php echo $show1['TOTAL_SEWA'] ?>"></td>
	</tr> -->
</table>
</div> 
<th colspan="2" scope="row">
</tr>
<th colspan="2" scope="row">
	<button type="submit" name="simpan" value="simpan" class="btn btn-primary">Simpan <span class="glyphicon glyphicon-ok"></button></a></button>

		<button type="reset" name="batal" value="batal" class="btn btn-danger">Batal <span class="glyphicon glyphicon-remove"></button></a>
			

			
		</th>
	</table>
</div>
</table>
</form>



</div>
</div>
<!-- END MAIN -->
<!-- Footer -->
<footer class="site-footer">
	<section  class="box-elements">
		<div class="container">
			<div class="row">
					<!-- <div class="col-xs-12 col-sm-6 col-md-12 col-lg-3">
						<figure class="footer_logo"><a href="#"><span><em>Ciliwung</em><strong>Camp</strong></span><i class="icon-111"></i></a></figure>
					</div> -->
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<h5>Perusahaan</h5>
						<ul class="footer-list">
							<li><a href="#">Beranda</a></li>
							<li><a href="#">Login</a></li>
							<li><a href="#">Produk</a></li>
							<li><a href="#">Kontak</a></li>
						</ul>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<h5>Customer Services</h5>
						<ul class="footer-list">
							<li><a href="#">Blog</a></li>
							<li><a href="#">FAQs</a></li>
							<li><a href="#">Help renting a product</a></li>
							<li><a href="#">Terms and Conditions</a></li>
						</ul>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<div class="contact-info">
							<span class="phone_number"><i class="icon-telephone"></i> 0822-3320-3907</span>
							
							<span class="location_info">
								<i class="icon-placeholder-for-map"></i>
								<em>Alamat Perusahaan</em> 
								<em>Ciliwung Camp</em> 
								<em>Jl. Ciliwung I No.76, Purwantoro, Kec. Blimbing, Kota Malang, Jawa Timur 65126</em> </span>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section class="site-footer__bottom-panel">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-md-6">
							<div class="copyright">&copy; 2019 | <a href="#">Created By</a> | <a href="#">State Polytechnic of Malang </a></div>
						</div>
						<div class="col-xs-12 col-md-6"> 
							<div class="social-list">
								<ul class="social-list__icons">
									<li><a href="#"><i class="icon-facebook-logo"></i></a></li>
									<li><a href="#"><i class="icon-twitter-letter-logo"></i></a></li>
									<li><a href="#"><i class="icon-google-plus"></i></a></li>
									<li><a href="#"><i class="icon-linkedin-logo"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</section>

			<a href="#" class="scrollup"><i class="icon-arrow-down-sign-to-navigate"></i></a>

		</footer>
		<!-- //Footer -->
		<!-- Google map -->
		<script src="assetss/js/jquery.1.12.4.min.js"></script>
		<script src="assetss/js/plugins/bootstrap.min.js"></script>
		<script src="assetss/js/plugins/wow.min.js"></script>
		<script src="assetss/js/plugins/jquery.smartmenus.min.js"></script>
		<script src="assetss/js/plugins/jquery.smartmenus.bootstrap.js"></script>
		<script src="assetss/js/plugins/jquery.nivo.slider.js"></script>
		<script src="assetss/js/plugins/swiper.min.js"></script>
		<script src="assetss/js/plugins/intlTelInput.min.js"></script>
		<script src="assetss/js/plugins/remodal.js"></script>
		<script src="assetss/js/plugins/stickup.min.js"></script>
		<script src="assetss/js/plugins/tool.js"></script>
		<script src="assetss/js/custom.js"></script>
	</body>