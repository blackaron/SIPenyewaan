<?php

include "koneksi.php"; //memanggil file koneksi.php untuk menghubungkan ke database


  if(isset($_POST['simpan'])) {
    $idReservasi = $_POST['ID_RESERVASI'];
    $tglpengembalian =$_POST['TGL_PENGEMBALIAN'];
    $denda = $_POST['DENDA'];
    $keterangan = $_POST['KETERANGAN'];
    $idBarang = 0;
    $jumlahBarang = 0;
    $stokSewa =0;
   

    $pengembalian = mysqli_query($koneksi, "INSERT INTO pengembalian SET ID_RESERVASI='$idReservasi' , TGL_PENGEMBALIAN = '$tglpengembalian', DENDA='$denda', KETERANGAN = '$keterangan'") or die ("data salah: ".mysqli_error($koneksi));

    $STATUS = mysqli_query($koneksi, "UPDATE reservasi SET STATUS='SUDAH KEMBALI' WHERE ID_RESERVASI='$idReservasi'") or die ("data salah: ".mysqli_error($koneksi));

    $STOK = mysqli_query($koneksi, "SELECT * FROM reservasi where id_reservasi='$idReservasi'");
                                                while ($show = mysqli_fetch_array($STOK)) {
                                                  $stokSewa = $show['JUMLAH_SEWA'];
                                                  $idBarang = $show['ID_BARANG'];
                                                }
$ambilStok = mysqli_query($koneksi, "SELECT * FROM barang where id_barang='$idBarang'");
while ($show = mysqli_fetch_array($ambilStok)) {
    $jumlahBarang = $show['STOK'];
}

                                               
                                                $totalStok = $jumlahBarang+$stokSewa;

    $updateStok = mysqli_query($koneksi, "UPDATE BARANG SET STOK='$totalStok' WHERE ID_BARANG='$idBarang'") or die ("data salah: ".mysqli_error($koneksi));


    
  if ($updateStok) {
		echo "<script>alert('Berhasil di tambahkan!')</script>";
        header("Location: dataSewa.php");
		

	}else{
		echo "<script>alert('gagal di tambahkan!');history.go(-1);</script>";
		
	}
        // Show message when user added
        
    }

    ?>

