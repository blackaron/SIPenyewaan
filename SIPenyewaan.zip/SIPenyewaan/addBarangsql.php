<?php

include "koneksi.php"; //memanggil file koneksi.php untuk menghubungkan ke database


  if(isset($_POST['simpan'])) {
       
    $nama_barang = $_POST['NAMA_BARANG'];
    $stok = $_POST['STOK'];
    $harga_sewa = $_POST['HARGA_SEWA'];
    $deskripsi = $_POST['DESKRIPSI'];
    $gambar = $_FILES['GAMBAR_BRG']['name'];
	$lokasi_file = $_FILES['GAMBAR_BRG']['tmp_name'];

    $path = "img/".$gambar;

    move_uploaded_file($lokasi_file, $path);

	// if($gambar != ''){
	// 	$path ="img/".$gambar;

	// 	move_uploaded_file($lokasi_file, $path);


    $barang = mysqli_query($koneksi, "INSERT INTO barang SET  NAMA_BARANG = '$nama_barang',STOK='$stok',HARGA_SEWA='$harga_sewa',DESKRIPSI='$deskripsi',GAMBAR_BRG='$gambar'") or die ("data salah: ".mysqli_error($koneksi));

  if ($barang) {
		echo "<script>alert('Berhasil di tambahkan!');history.go(-1);</script>";
		

	}else{
		echo "<script>alert('gagal di tambahkan!');history.go(-1);</script>";
		
	}
        // Show message when user added
        
    }

    ?>

