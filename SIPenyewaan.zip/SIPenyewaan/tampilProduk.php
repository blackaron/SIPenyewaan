<?php
include 'koneksi.php';
// include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="html 5 template">
	<meta name="author" content="tonytemplates.com">
<!-- 	<link rel="icon" href="favicon.ico"> -->
	<title>Ciliwung Camp</title>
	<!-- Bootstrap core CSS -->
	<link href="assetss/css/plugins/bootstrap.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/jquery.smartmenus.bootstrap.css" rel="stylesheet">
	<link href="assetss/css/plugins/nivo-slider.css" rel="stylesheet">
	<link href="assetss/css/plugins/swiper.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/intlTelInput.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/remodal.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/animate.css" rel="stylesheet">
	<link href="assetss/css/main-style.css" rel="stylesheet">
	<link href="iconfont/style.css" rel="stylesheet">
	<!-- Google Fonts -->
	<link href="#" rel="stylesheet">
</head>
<body class="page__fleet">
	<main id="page-content">
		<div style="text-align: center;">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="breadcrumbs__title">Produk</div>
						<div class="breadcrumbs__items">
							<div class="breadcrumbs__wrap">
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<section class="isotop-box">
		
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
					<?php
					$show = mysqli_query($koneksi, "SELECT * FROM barang WHERE ID_BARANG");
					?>
					<?php
                    if($show->num_rows>0){
                    	while($data = $show->fetch_object()){
					?>
						<div class="gallery gallery-isotope" id="gallery">
							<div class="gallery__item category2 category5">
								<figure class="gallery__item__image" >
									<a class="hover" href="index.php?hal=sewa&id=<?php echo $data->ID_BARANG?>">
										<img src="img/<?php echo $data->GAMBAR_BRG?>" alt=""/>
										<i class="icon-arrow-down-sign-to-navigate2"></i>
									</a>
								</figure>
								<div class="gallery__item__content">
									<h6><?php echo $data->NAMA_BARANG?> <br>STOK = <?php echo $data->STOK?></h6>
									<span class="cost" ><span style="text-align: center;"><?php echo $data->HARGA_SEWA?> /day</span></span>
									<button type="button" class="btn btn-info"><a href="detail_produk.php?ID_BARANG=<?php echo $data->ID_BARANG?>">Detail</a></button>
									
								</div>
							</div>
						</div>
						<?php
					}
				}
				?>
					</div>
				</div> <!-- //row -->
			</div> <!-- //Container -->

		</section>
	</main>
	<!-- Footer -->
	<footer class="site-footer">
		<section  class="box-elements">
			<div class="container">
				<div class="row">
					<!-- <div class="col-xs-12 col-sm-6 col-md-12 col-lg-3">
						<figure class="footer_logo"><a href="#"><span><em>Ciliwung</em><strong>Camp</strong></span><i class="icon-111"></i></a></figure>
					</div> -->
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<h5>Perusahaan</h5>
						<ul class="footer-list">
							<li><a href="#">Beranda</a></li>
							<li><a href="#">Login</a></li>
							<li><a href="#">Produk</a></li>
							<li><a href="#">Kontak</a></li>
						</ul>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<h5>Customer Services</h5>
						<ul class="footer-list">
							<li><a href="#">Blog</a></li>
							<li><a href="#">FAQs</a></li>
							<li><a href="#">Help renting a product</a></li>
							<li><a href="#">Terms and Conditions</a></li>
						</ul>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<div class="contact-info">
							<span class="phone_number"><i class="icon-telephone"></i> 0822-3320-3907</span>
							
							<span class="location_info">
							<i class="icon-placeholder-for-map"></i>
							<em>Alamat Perusahaan</em> 
							<em>Ciliwung Camp</em> 
							<em>Jl. Ciliwung I No.76, Purwantoro, Kec. Blimbing, Kota Malang, Jawa Timur 65126</em> </span>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section class="site-footer__bottom-panel">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-md-6">
						<div class="copyright">&copy; 2019 | <a href="#">Created By</a> | <a href="#">State Polytechnic of Malang </a></div>
					</div>
					<div class="col-xs-12 col-md-6"> 
						<div class="social-list">
							<ul class="social-list__icons">
								<li><a href="#"><i class="icon-facebook-logo"></i></a></li>
								<li><a href="#"><i class="icon-twitter-letter-logo"></i></a></li>
								<li><a href="#"><i class="icon-google-plus"></i></a></li>
								<li><a href="#"><i class="icon-linkedin-logo"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>
		
		<a href="#" class="scrollup"><i class="icon-arrow-down-sign-to-navigate"></i></a>

	</footer>
	<!-- //Footer -->
	<!-- Google map -->
	<script src="assetss/js/jquery.1.12.4.min.js"></script>
	<script src="assetss/js/plugins/bootstrap.min.js"></script>
	<script src="assetss/js/plugins/wow.min.js"></script>
	<script src="assetss/js/plugins/jquery.smartmenus.min.js"></script>
	<script src="assetss/js/plugins/jquery.smartmenus.bootstrap.js"></script>
	<script src="assetss/js/plugins/jquery.nivo.slider.js"></script>
	<script src="assetss/js/plugins/swiper.min.js"></script>
	<script src="assetss/js/plugins/intlTelInput.min.js"></script>
	<script src="assetss/js/plugins/remodal.js"></script>
	<script src="assetss/js/plugins/stickup.min.js"></script>
	<script src="assetss/js/plugins/tool.js"></script>
	<script src="assetss/js/custom.js"></script>
	
</body>