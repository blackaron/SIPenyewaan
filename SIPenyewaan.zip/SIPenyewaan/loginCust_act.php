<?php 
include('koneksi.php');
session_start();
$act = $_GET['act'];
$EMAIL= $_POST['username'];
$PASSWORD= md5 ($_POST['password']);
if(isset($_GET['act'])){
	if($act == 1){
		$result=$koneksi->query("SELECT * FROM user WHERE EMAIL = '$EMAIL' AND PASSWORD = '$PASSWORD'");
		$data=$result->num_rows;
		if ($data == 1) {
			$row = $result->fetch_object();
			$_SESSION['ID_USER'] 				= $row->ID_USER;
		 	$_SESSION['nama_cs'] 			= $row->NAMA;
		 	// $_SESSION['kelamin_cs'] 		= $row->kelamin_cs;
		 	$_SESSION['alamat_cs'] 			= $row->ALAMAT;
		 	$_SESSION['telp_cs']			= $row->NO_HP;
		 	$_SESSION['username_cs']		= $row->EMAIL;
		 	$_SESSION['password_cs']		= $row->PASSWORD;
		 	// $_SESSION['level_cs']			= $row->level_cs;
			echo"<script>alert ('Selamat datang ".$EMAIL."');
	                   window.location='index.php?hal=home'</script>";
			
	}else{
		echo"<script>alert ('Anda Gagal Login');
	window.location='loginCust.php?hal=login'</script>";
	}
}
}

?>
