<?php
if (isset($_POST['daftar'])) {
	include('koneksi.php');
	session_start();
  
  $NAMA			=$_POST['NAMA'];
  $ALAMAT		=$_POST['ALAMAT'];
  $NO_HP		=$_POST['NO_HP'];
  $EMAIL		=$_POST['EMAIL'];
  $PASSWORD		=md5 ($_POST['PASSWORD']);
  $cek = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM user WHERE EMAIL='".$EMAIL."'"));
        if ($cek > 0){
                echo "<script>alert('Username sudah ada !');window.location='index.php?hal=login'</script>";
        }else{
  			$querymasuk="INSERT INTO user(NAMA, ALAMAT, NO_HP, EMAIL, PASSWORD) VALUE ('$NAMA', '$ALAMAT', '$NO_HP', '$EMAIL', '$PASSWORD')";
  		$masuk=$koneksi->query($querymasuk);
  				if($masuk){
   				 echo "<script>alert('Anda Berhasil Daftar !');window.location='index.php?hal=login'</script>";
    			echo"<script>alert ('Selamat datang ".$user."');
	                   window.location='index.php?page=home'</script>";
  				}

		}
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="html 5 template">
	<meta name="author" content="tonytemplates.com">
	<link rel="icon" href="favicon.ico">
	<title>Ciliwung Camp</title>
	<link href="assetss/css/plugins/bootstrap.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/jquery.smartmenus.bootstrap.css" rel="stylesheet">
	<link href="assetss/css/plugins/nivo-slider.css" rel="stylesheet">
	<link href="assetss/css/plugins/swiper.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/intlTelInput.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/remodal.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/animate.css" rel="stylesheet">
	<link href="assetss/css/main-style.css" rel="stylesheet">
	<link href="iconfont/style.css" rel="stylesheet">
</head>

<body class="page__home">
	<main id="page-content">
		<div class="container">
			<div class="row">
				
				<div class="col-xs-6">
					<form action="#" class="order-details-form" name="" method="post" novalidate>
						<div class="inner-form" >
						<div class="header">
								<div class="logo text-center"><img src="assets/img/logo.png" alt="Klorofil Logo"></div>
								<p class="lead">Registration</p>
							</div>
							<br>
										<div cl>
											<input type="text" name="NAMA" placeholder="Nama Lengkap" style="text-align: center;width: 80%" required="">
										</div>
										<div >
											<input type="text" name="ALAMAT" placeholder="Alamat" required="" style="text-align: center;width: 80%">
										</div>
										<div >
											<input type="text" name="NO_HP" placeholder="No. Telepon" required="" style="text-align: center;width: 80%">
										</div>
										<div >
											<input type="text" name="EMAIL" placeholder="Email" required="" style="text-align: center;width: 80%">
										</div>
										<div >
											<input type="password" name="PASSWORD" placeholder="Password" required="" style="text-align: center;width: 80%">
										</div>
										
										<br>
							<button type="submit" class="btn" name="daftar" value="Lanjut"><a href="index_user.php?hal=home">REGISTRATION</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</main>
	
	<script src="assetss/js/jquery.1.12.4.min.js"></script>
	<script src="assetss/js/plugins/bootstrap.min.js"></script>
	<script src="assetss/js/plugins/wow.min.js"></script>
	<script src="assetss/js/plugins/jquery.smartmenus.min.js"></script>
	<script src="assetss/js/plugins/jquery.smartmenus.bootstrap.js"></script>
	<script src="assetss/js/plugins/jquery.nivo.slider.js"></script>
	<script src="assetss/js/plugins/swiper.min.js"></script>
	<script src="assetss/js/plugins/intlTelInput.min.js"></script>
	<script src="assetss/js/plugins/remodal.js"></script>
	<script src="assetss/js/plugins/stickup.min.js"></script>
	<script src="assetss/js/plugins/tool.js"></script>
	<script src="assetss/js/custom.js"></script>
</body>
</html>
