<?php 
include('koneksi.php');
session_start();
$act = $_GET['act'];
$EMAIL= $_POST['EMAIL'];
$PASSWORD= md5 ($_POST['PASSWORD']);
if(isset($_GET['act'])){
	if($act == 1){
		$result=$koneksi->query("SELECT * FROM user WHERE EMAIL = '$EMAIL' AND PASSWORD = '$PASSWORD'");
		$data=$result->num_rows;
		if ($data == 1) {
			$row = $result->fetch_object();
			$_SESSION['ID_USER'] 	= $row->ID_USER;
		 	$_SESSION['NAMA'] 		= $row->NAMA;
		 	$_SESSION['ALAMAT']		= $row->ALAMAT;
		 	$_SESSION['EMAIL']		= $row->EMAIL;
		 	$_SESSION['NO_HP']		= $row->NO_HP;
		 	$_SESSION['PASSWORD']	= $row->PASSWORD;
			echo"<script>alert ('Selamat datang ".$NAMA."');
	                   window.location='index.php'</script>";
			
	}else{
		echo"<script>alert ('Anda Gagal Login');
	window.location='index.php'</script>";
	}
}
}

?>
