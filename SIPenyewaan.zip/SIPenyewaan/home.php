<figure class="thumbnail move_img wow slideInLeft" data-wow-delay="0.5s"></figure>
<div class="container">
	<div class="row">
		<div class="col-sm-12 col-lg-6 col-lg-push-6">
		<?php 
		   if(!isset($_SESSION['EMAIL'])){
		?>
			<h1>Selamat Datang</h1>
		<?php }else{ ?>
		<h1>Selamat Datang</h1>
			<p><?php echo $_SESSION['NAMA'] ?></p>
		<?php } ?>
		</div>
	</div>
</div>
