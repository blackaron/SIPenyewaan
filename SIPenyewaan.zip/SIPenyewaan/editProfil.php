<?php
include "koneksi.php";
include "header.php";

$query = mysqli_query($koneksi, "SELECT * FROM user WHERE ID_USER = 1");
$data = mysqli_fetch_array($query); //menampilkan data yang sudah dipilih untuk diedit
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="html 5 template">
	<meta name="author" content="tonytemplates.com">
<!-- 	<link rel="icon" href="favicon.ico"> -->
	<title>Ciliwung Camp</title>
	<!-- Bootstrap core CSS -->
	<link href="assetss/css/plugins/bootstrap.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/jquery.smartmenus.bootstrap.css" rel="stylesheet">
	<link href="assetss/css/plugins/nivo-slider.css" rel="stylesheet">
	<link href="assetss/css/plugins/swiper.min.css" rel="stylesheet">
	<link href="assetss/css/plugins/intlTelInput.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/remodal.min.css" rel="stylesheet" >
	<link href="assetss/css/plugins/animate.css" rel="stylesheet">
	<link href="assetss/css/main-style.css" rel="stylesheet">
	<link href="iconfont/style.css" rel="stylesheet">
	<!-- Google Fonts -->
	<link href="#" rel="stylesheet">
</head>
<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Profil</h3>
						<div class="row">
						<div class="col-md-12">
							<!-- BORDERED TABLE -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Data Diri</h3>
									
								</div>
								<div class="panel-body">
									<table class="table table-bordered table-hover">
									
											<?php
											$ambilUser = $_SESSION["USERNAME"]; 
								$user = mysqli_query($koneksi, "SELECT * FROM USER WHERE USERNAME='$ambilUser'");
											while ($data = mysqli_fetch_array($user)) {
											?>
		<!-- LINK HALAMAN -->
		<form action="edit-proses.php?ID_USER=<?php echo $data['ID_USER']; ?>" method="post">
		<input type="hidden" name="id" value="<?php echo $id; ?>">	<!-- membuat inputan hidden dan nilainya adalah siswa_id -->
		<center><table cellpadding="3" cellspacing="0">
			<tr>
				<td>Nama Lengkap</td>
				<td>:</td>
				<td><input type="text" name="nama" size="30" value="<?php echo $data['NAMA']; ?>" required></td> <!-- value diambil dari hasil query -->
			</tr>
			<tr>
				<td>Alamat</td>
				<td>:</td>
				<td><input type="text" name="alamat" size="30" value="<?php echo $data['ALAMAT']; ?>" required></td> <!-- value diambil dari hasil query -->
			</tr>
			<tr>
				<td>NO TELP</td>
				<td>:</td>
				<td><input type="text" name="notelp" value="<?php echo $data['NO_HP']; ?>" required></td>	<!-- value diambil dari hasil query -->
			</tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td><input type="text" name="email" size="50" value="<?php echo $data['EMAIL']; ?>" required></td> <!-- value diambil dari hasil query -->
			</tr>

			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" name="update" value="EDIT"><a href "profile.php>"></td>
			</tr>

		</table>
		<?php
		}
			?>	
		</center>
	</form>

								</div>

							</div>
							<!-- END BORDERED TABLE -->
						</div>
		<!-- END MAIN -->
		<!-- <div class="clearfix"></div>
		<footer>
			<div class="container-fluid">
				<p class="copyright">&copy; 2017 <a href="https://www.themeineed.com" target="_blank">Theme I Need</a>. All Rights Reserved.</p>
			</div>
		</footer>
	</div> -->
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
	<script src="assets/vendor/chartist/js/chartist.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>
	<script>
	$(function() {
		var data, options;

		// headline charts
		data = {
			labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
			series: [
				[23, 29, 24, 40, 25, 24, 35],
				[14, 25, 18, 34, 29, 38, 44],
			]
		};

		options = {
			height: 300,
			showArea: true,
			showLine: false,
			showPoint: false,
			fullWidth: true,
			axisX: {
				showGrid: false
			},
			lineSmooth: false,
		};

		new Chartist.Line('#headline-chart', data, options);


		// visits trend charts
		data = {
			labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
			series: [{
				name: 'series-real',
				data: [200, 380, 350, 320, 410, 450, 570, 400, 555, 620, 750, 900],
			}, {
				name: 'series-projection',
				data: [240, 350, 360, 380, 400, 450, 480, 523, 555, 600, 700, 800],
			}]
		};

		options = {
			fullWidth: true,
			lineSmooth: false,
			height: "270px",
			low: 0,
			high: 'auto',
			series: {
				'series-projection': {
					showArea: true,
					showPoint: false,
					showLine: false
				},
			},
			axisX: {
				showGrid: false,

			},
			axisY: {
				showGrid: false,
				onlyInteger: true,
				offset: 0,
			},
			chartPadding: {
				left: 20,
				right: 20
			}
		};

		new Chartist.Line('#visits-trends-chart', data, options);


		// visits chart
		data = {
			labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
			series: [
				[6384, 6342, 5437, 2764, 3958, 5068, 7654]
			]
		};

		options = {
			height: 300,
			axisX: {
				showGrid: false
			},
		};

		new Chartist.Bar('#visits-chart', data, options);


		// real-time pie chart
		var sysLoad = $('#system-load').easyPieChart({
			size: 130,
			barColor: function(percent) {
				return "rgb(" + Math.round(200 * percent / 100) + ", " + Math.round(200 * (1.1 - percent / 100)) + ", 0)";
			},
			trackColor: 'rgba(245, 245, 245, 0.8)',
			scaleColor: false,
			lineWidth: 5,
			lineCap: "square",
			animate: 800
		});

		var updateInterval = 3000; // in milliseconds

		setInterval(function() {
			var randomVal;
			randomVal = getRandomInt(0, 100);

			sysLoad.data('easyPieChart').update(randomVal);
			sysLoad.find('.percent').text(randomVal);
		}, updateInterval);

		function getRandomInt(min, max) {
			return Math.floor(Math.random() * (max - min + 1)) + min;
		}

	});
	</script>
</body>

</html>
