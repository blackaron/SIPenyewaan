<?php
	session_start();
	if(!isset($_SESSION['USERNAME']) ){
	echo"<script>window.alert('maaf anda harus login terlebih dahulu')</script>";
	echo"<script>window.location=('index.php')</script>";
	exit();
}include "koneksi.php";
$id_reservasi = $_GET['ID_RESERVASI'];

		$pinjam = mysqli_query($koneksi,"UPDATE reservasi SET STATUS ='BELUM KEMBALI' where ID_RESERVASI=$id_reservasi") or die ("data salah : ".mysqli_error($koneksi));	

		header('Location: dataSewa.php');
?>