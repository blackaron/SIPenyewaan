<?php

include "koneksi.php"; //memanggil file koneksi.php untuk menghubungkan ke database


  if(isset($_POST['simpan'])) {
    $idReservasi = $_GET['ID_RESERVASI'];
    $nama_pengirim = $_POST['NAMA_PENGIRIM'];
    $nama_bank = $_POST['ASAL_BANK'];
    $tanggal_bayar = $_POST['TGL_BAYAR'];
    $jumlah_bayar = $_POST['JUMLAH_BAYAR'];
    $gambar = $_FILES['BUKTI_BAYAR']['name'];
    $idReservasi = $_POST['ID_RESERVASI'];
    $lokasi_file = $_FILES['BUKTI_BAYAR']['tmp_name'];

    $path = "img/".$gambar;

    move_uploaded_file($lokasi_file, $path);

    // if($gambar != ''){
    //  $path ="img/".$gambar;

    //  move_uploaded_file($lokasi_file, $path);


    $pembayaran = mysqli_query($koneksi, "INSERT INTO pembayaran SET ID_RESERVASI='$idReservasi', NAMA_PENGIRIM = '$nama_pengirim', ASAL_BANK='$nama_bank', TGL_BAYAR='$tanggal_bayar', JUMLAH_BAYAR='$jumlah_bayar',BUKTI_BAYAR='$gambar'") or die ("data salah: ".mysqli_error($koneksi));

    $pembayaran = mysqli_query($koneksi, "UPDATE RESERVASI SET STATUS='MENUNGGU KONFIRMASI PEMBAYARAN' WHERE ID_RESERVASI='$idReservasi'") or die ("data salah: ".mysqli_error($koneksi));

  if ($pembayaran) {
        echo "<script>alert('Berhasil di tambahkan!')</script>";
        header("Location: riwayat2.php");
        

    }else{
        echo "<script>alert('gagal di tambahkan!');history.go(-1);</script>";
        
    }
        // Show message when user added
        
    }

    ?>

