<?php
  require_once('header.php');
?>

	<main id="page-content">
			<div class="container" style="text-align: center;">
				<div class="row">
					<div class="col-xs-12">
						<div class="breadcrumbs__title">Kontak</div>
						<div class="breadcrumbs__items">
								
						</div>
					</div>
				</div>
			</div>
		<!-- // Breadcrumbs  -->
		<section class="contact-map">
			<div id="contacts-map"></div>
			<div class="contact-info-block">
				<div class="logo-contacts">
					<div class="logo">
						<a href="#">
							<i class="icon-logo"></i>
							<span>Ciliwung</span>Camp
						</a>
					</div>
				</div>
				<div class="contact-info">
					<span class="phone_number"><i class="icon-telephone"></i> 0822-3320-3907</span>
					<span class="location_info">
					<i class="icon-placeholder-for-map"></i>
					<em>Alamat Perusahaan</em> 
					<em>Ciliwung Camp</em> 
					<em>Jl. Ciliwung I No.76, Purwantoro, Kec. Blimbing, Kota Malang, Jawa Timur 65126</em> </span>
				</div>
				<!-- <div class="social-list">
					<ul class="social-list__icons">
						<li><a href="#"><i class="icon-facebook-logo"></i></a></li>
						<li><a href="#"><i class="icon-twitter-letter-logo"></i></a></li>
						<li><a href="#"><i class="icon-google-plus"></i></a></li>
						<li><a href="#"><i class="icon-linkedin-logo"></i></a></li>
					</ul>
				</div> -->
			</div>
		</section>
	</main>