<?php
include 'koneksi.php';
// include 'header.php';
session_start();

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Warehouse &mdash; Website Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,900|Oswald:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  
  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    


    
    <div class="site-block-wrap">
    <div class="owl-carousel with-dots">
      <div class="site-blocks-cover overlay overlay-2" style="background-image: url(img/c.jpg);" data-aos="fade" id="home-section">


        <div class="container">
          <div class="row align-items-center justify-content-center">
            <div class="col-md-6 mt-lg-5 text-center">
              <h1 class="text-shadow">Rental &amp; Alat Outdoor</h1>
              <p class="mb-5 text-shadow">Meayani peminjaman alat outdor dan penghantaran</p>
             <!--  <p><a href="#" target="_blank" class="btn btn-primary px-5 py-3">Get Started</a></p> -->
              
            </div>
          </div>
        </div>
  
        
      </div>  
  
      <div class="site-blocks-cover overlay overlay-2" style="background-image: url(img/b.jpg);" data-aos="fade" id="home-section">
  
  
        <div class="container">
          <div class="row align-items-center justify-content-center">
            <div class="col-md-6 mt-lg-5 text-center">
              <h1 class="text-shadow">Temukan alat mu disini</h1>
              <p class="mb-5 text-shadow">Lakukan Penyewaan</p>
            <!--   <p><a href="#" target="_blank" class="btn btn-primary px-5 py-3">Get Started</a></p> -->
              
            </div>
          </div>
        </div>
  
        
      </div>  
    </div>   
    
  </div>   
<main id="page-content">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<form action="#" class="order-details-form" name="" method="post" novalidate>
						<div class="inner-form" >
								<?php
								$ambilUser = $_SESSION["USERNAME"]; 
								$tampil = mysqli_query($koneksi, "SELECT * FROM USER WHERE USERNAME='$ambilUser'");
								?>
								<?php
			                    if($tampil->num_rows>0){
			                    	// $_SESSION["ID_USER"] = $row_akun["ID_USER"];
			                    	// $_SESSION["NAMA"] = $row_akun["NAMA"];
			                    	// $_SESSION["ALAMAT"] = $row_akun["ALAMAT"];
			                    	// $_SESSION["NO_HP"] = $row_akun["NO_HP"];
			                    	// $_SESSION["EMAIL"] = $row_akun["EMAIL"];

			                    	while($data = $tampil->fetch_object()){
								?>
						<h3>Profile</h3>
										<div>
											<input type="hidden" name="ID_USER" placeholder="ID" style="text-align: center;width: 30%" required="" readonly="" value="<?php echo $data->ID_USER?>">
										</div>
										<div >
											<input type="text" name="NAMA" placeholder="Nama Lengkap" style="text-align: center;width: 30%" required="" readonly="" value="<?php echo $data->NAMA?>">
										</div>
									
										<div >
											<input type="text" name="ALAMAT" placeholder="Alamat" required="" style="text-align: center;width: 30%" readonly="" value="<?php echo $data->ALAMAT?>">
										</div>
										<div >
											<input type="text" name="NO_HP" placeholder="No. Telepon" required="" style="text-align: center;width: 30%" readonly="" value="<?php echo $data->NO_HP?>">
										</div>
										<div >
											<input type="text" name="EMAIL" placeholder="Username" required="" style="text-align: center;width: 30%" readonly=" " value="<?php echo $data->EMAIL?>">
										</div>
										<div >
											<input type="hidden" name="PASSWORD" placeholder="Password" required="" style="text-align: center;width: 30%" readonly="" value="<?php echo $data->PASSWORD?>">
										</div>
										
										<br>
							
							
								<td><button class="btn btn-warning" ><a href="editProfil.php?ID_USER=<?php echo $show['ID_USER'];?>">Edit</a></button>
							</td>
							<?php
								}
							}
							?>
							<br>
						</div>
					</form>
					<br>
				</div>
			</div>
		</div>
	</main>
	<!-- Footer -->
	<footer class="site-footer">
		<section  class="box-elements">
			<div class="container">
				<div class="row">
					<!-- <div class="col-xs-12 col-sm-6 col-md-12 col-lg-3">
						<figure class="footer_logo"><a href="#"><span><em>Ciliwung</em><strong>Camp</strong></span><i class="icon-111"></i></a></figure>
					</div> -->
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<h5>Perusahaan</h5>
						<ul class="footer-list">
							<li><a href="#">Beranda</a></li>
							<li><a href="#">Login</a></li>
							<li><a href="#">Produk</a></li>
							<li><a href="#">Kontak</a></li>
						</ul>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<h5>Customer Services</h5>
						<ul class="footer-list">
							<li><a href="#">Blog</a></li>
							<li><a href="#">FAQs</a></li>
							<li><a href="#">Help renting a product</a></li>
							<li><a href="#">Terms and Conditions</a></li>
						</ul>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<div class="contact-info">
							<span class="phone_number"><i class="icon-telephone"></i> 0822-3320-3907</span>
							
							<span class="location_info">
							<i class="icon-placeholder-for-map"></i>
							<em>Alamat Perusahaan</em> 
							<em>Ciliwung Camp</em> 
							<em>Jl. Ciliwung I No.76, Purwantoro, Kec. Blimbing, Kota Malang, Jawa Timur 65126</em> </span>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section class="site-footer__bottom-panel">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-md-6">
						<div class="copyright">&copy; 2019 | <a href="#">Created By</a> | <a href="#">State Polytechnic of Malang </a></div>
					</div>
					<div class="col-xs-12 col-md-6"> 
						<div class="social-list">
							<ul class="social-list__icons">
								<li><a href="#"><i class="icon-facebook-logo"></i></a></li>
								<li><a href="#"><i class="icon-twitter-letter-logo"></i></a></li>
								<li><a href="#"><i class="icon-google-plus"></i></a></li>
								<li><a href="#"><i class="icon-linkedin-logo"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>
		
		<a href="#" class="scrollup"><i class="icon-arrow-down-sign-to-navigate"></i></a>

	</footer>
	<!-- //Footer -->
	<!-- Google map -->
	<script src="assetss/js/jquery.1.12.4.min.js"></script>
	<script src="assetss/js/plugins/bootstrap.min.js"></script>
	<script src="assetss/js/plugins/wow.min.js"></script>
	<script src="assetss/js/plugins/jquery.smartmenus.min.js"></script>
	<script src="assetss/js/plugins/jquery.smartmenus.bootstrap.js"></script>
	<script src="assetss/js/plugins/jquery.nivo.slider.js"></script>
	<script src="assetss/js/plugins/swiper.min.js"></script>
	<script src="assetss/js/plugins/intlTelInput.min.js"></script>
	<script src="assetss/js/plugins/remodal.js"></script>
	<script src="assetss/js/plugins/stickup.min.js"></script>
	<script src="assetss/js/plugins/tool.js"></script>
	<script src="assetss/js/custom.js"></script>