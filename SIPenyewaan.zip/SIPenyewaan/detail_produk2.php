<?php
include 'koneksi.php'; 
include 'header.php';

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Warehouse &mdash; Website Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,900|Oswald:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  
  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   

    
    <div class="site-blocks-cover inner-page-cover overlay" style="background-image: url(img/b.jpg);" data-aos="fade">
      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-5 mx-auto mt-lg-5 text-center">
            <h1>Detail Produk</h1>
            
          </div>
        </div>
      </div>

      <a href="#property-details" class="smoothscroll arrow-down"><span class="icon-arrow_downward"></span></a>
    </div>  



     <div class="site-section" id="property-details">
      <div class="container">
        <div class="row">
           <?php
              $ID_BARANGNYA = $_GET['ID_BARANG'];
              $show = mysqli_query($koneksi, "SELECT * FROM barang WHERE ID_BARANG=$ID_BARANGNYA");
              ?>
              <?php
              if($show->num_rows>0){
                while($data = $show->fetch_object()){
                  ?>
          <div class="col-lg-5">
            <div class="owl-carousel slide-one-item with-dots">
              <div> <img src="img/<?php echo $data->GAMBAR_BRG?>" alt="FImageo" class="img-fluid"></div>
            </div>
          </div>

          <div class="col-lg-5 pl-lg-5 ml-auto">
            <div class="mb-5">
              <h3 class="text-black mb-4">Property Details</h3>
              <p>Nama : <?php echo $data->NAMA_BARANG?></p>
              <p>Harga Sewa: <?php echo $data->HARGA_SEWA?></p>
              <p>Stok :  <?php echo $data->STOK?></p>
              <p>Deskripsi :<?php echo $data->DESKRIPSI?></p>
              <p><a href="isiformsewa2.php?ID_BARANG=<?php echo $data->ID_BARANG?>" class="btn btn-primary">Sewa</a></p>
            </div>

 <?php
                  }
                }
                ?>
          </div>
        </div>
      </div>
    </div>


    
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <div class="row">
              <div class="col-md-5">
                <h2 class="footer-heading mb-4">About Us</h2>
                <p>CV. CiliwungCamp Nusantara.<br>
                Jl. Ciliwung I No.76, Purwantoro, Kec. Blimbing, Kota Malang, Jawa Timur 65126.<br>
              0851-0396-5552</p>              </div>
              <!-- <div class="col-md-3 mx-auto">
                <h2 class="footer-heading mb-4">Quick Links</h2>
                <ul class="list-unstyled">
                  <li><a href="#">About Us</a></li>
                  <li><a href="#">Services</a></li>
                  <li><a href="#">Testimonials</a></li>
                  <li><a href="#">Contact Us</a></li>
                </ul>
              </div> -->
              
            </div>
          </div>
          <!-- <div class="col-md-4">
            <div class="mb-4">
              <h2 class="footer-heading mb-4">Subscribe Newsletter</h2>
            <form action="#" method="post" class="footer-subscribe">
              <div class="input-group mb-3">
                <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="button-addon2">
                <div class="input-group-append">
                  <button class="btn btn-primary text-black" type="button" id="button-addon2">Send</button>
                </div>
              </div>
            </form>  
            </div> -->
            
            <div class="">
              <h2 class="footer-heading mb-4">Follow Us</h2>
                <a href="https://www.facebook.com/CiliwungCampOutdoorService/" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                <a href="https://twitter.com/ciliwungcamp/status/550520866770264064?lang=ar" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                <a href="https://www.instagram.com/ciliwungcamp/?hl=id" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                <!-- <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a> -->
            </div>


          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <div class="border-top pt-5">
            <p class="copyright">
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
            </div>
          </div>
          
        </div>
      </div>
    </footer>

  </div> <!-- .site-wrap -->

  <a href="#top" class="gototop"><span class="icon-angle-double-up"></span></a> 

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>

  
  <script src="js/main.js"></script>
    
  </body>
</html>