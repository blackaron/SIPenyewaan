<?php
$kode=$_POST['kodever'];
if($kode==19877) //isikan angka kode yang sesuai dengan yang ada pada halaman send.php
{
header("location: login.php");
}
else{
header("location: verifikasiOtp.php");
}
?>