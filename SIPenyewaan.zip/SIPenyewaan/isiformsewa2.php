<?php
include "koneksi.php";
include "header.php";
date_default_timezone_set('Asia/Jakarta');
session_start();
if(!isset($_SESSION['USERNAME']) ){
  echo"<script>window.alert('maaf anda harus login terlebih dahulu')</script>";
  echo"<script>window.location=('index.php')</script>";
  exit();
}
include "koneksi.php";

$username = $_SESSION['USERNAME'];
$user = mysqli_query($koneksi,"SELECT * FROM user where USERNAME='$username'");
$showuser = mysqli_fetch_array($user);

$barang = mysqli_query($koneksi,"SELECT * FROM barang where ID_BARANG='$_GET[ID_BARANG]'");
$show = mysqli_fetch_array($barang);

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Warehouse &mdash; Website Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,900|Oswald:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  
  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   

    
    <div class="site-blocks-cover inner-page-cover overlay" style="background-image: url(img/b.jpg);" data-aos="fade">
      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-5 mx-auto mt-lg-5 text-center">
            <h1>Isi Form Penyewaan</h1>
            
          </div>
        </div>
      </div>

      <a href="#property-details" class="smoothscroll arrow-down"><span class="icon-arrow_downward"></span></a>
    </div>  
    

              
              <div class="comment-form-wrap pt-5">
                <center><h3 class="mb-5">Form Sewa</h3></center>

               <form action="isiformsql2.php" method="POST" enctype="multipart/form-data" class="p-5 bg-light">
                  <div class="form-group">
                    <input type="hidden" name="id_pinjam" required="" value="">
                    <label for="name">Tanggal Reservasi</label>
                    <p><?php echo date("Y/m/d h:i:s");?></p>
               <!--    </div>
                  
                  <div class="form-group"> -->
                    <label for="email">Nama</label>
                    <p><?php echo $showuser['NAMA'] ?></p></td>
                    <td><input type="hidden" name="ID_USER" required="" value="<?php echo $showuser['ID_USER'] ?>"></td>
                 <!--  </div>
                  <div class="form-group"> -->
                    <label for="website">Nama Barang</label>
                    <p><?php echo $show['NAMA_BARANG'] ?></p>
                  <!-- </div>
                   <div class="form-group"> -->
                    <!-- <label for="website">Id Barang</label> -->
                    <td><input type="hidden" class="form-control" name="ID_BARANG" required="" value="<?php echo $show['ID_BARANG'] ?>"</td>
                    <td><input type="hidden" name="HARGA_SEWA"value="<?php echo $show['HARGA_SEWA']?>" ></td>
                 <!--  </div>
                  <div class="form-group"> -->
                    <label for="website">Tanggal Pinjam</label>
                    <input type="Date" class="form-control"  name="TGL_PINJAM" required="" placeholder="Tanggal Pinjam" >
                 <!--  </div>
                  <div class="form-group"> -->
                    <label for="website">Tanggal Kembali</label>
                    <input type="Date" class="form-control"  name="TGL_KEMBALI" required="" placeholder="Tanggal Kembali" >
                 <!--  </div>
                  <div class="form-group"> -->
                    <label for="website">Jumlah Barang</label>
                    <input type="text" class="form-control"  name="JUMLAH_SEWA" required="" min=1 max="<?php echo $show['JUMLAH_SEWA'] ?>" >
                    <td><input type="hidden" name="JUMLAH_STOK"value="<?php echo $show['STOK']?>" ></td>
                  <!-- </div>
                  <div class="form-group"> -->
                    <label >Jaminan</label>
                  <select name="JAMINAN" class="form-control">
                    
                      <option value="">Silahkan Pilih</option>  
                      <option value="KTP">KTP</option>  
                      <option value="SIM">SIM</option>
                      <option value="KTM">KTM</option>     
                    </select> 
                <!--   </div>
                 <div class="form-group"> -->
                    <label for="website">No Identitas</label>
                    <input type="text" class="form-control"  name="NO_IDENTITAS" required="">
                <!--   </div>
                  <div class="form-group"> -->
                    <label>Metode Pengambilan Alat</label>
                  <select name="METODE_PENGAMBILAN" class="form-control">
                    
                      <option value="">Silahkan Pilih</option>   
                      <option value="Ambil Ke Toko">Ambil Ke Toko</option>  
                      <option value="Dikirim Ke Alamat Pengiriman">Dikirim Ke Alamat Pengiriman</option>      
                    </select> 
                 <!--  </div>

                  <div class="form-group"> -->
                    <label for="message">Alamat Pengiriman</label>
                    <textarea  name="ALAMAT_KIRIM" id="ALAMAT_KIRIM" cols="30" rows="10" class="form-control"></textarea>
                  <!-- </div>

                  <div class="form-group"> -->
                  <button type="reset" name="batal" value="batal" class="btn btn-danger">Batal <span class="glyphicon glyphicon-remove"></button>
                 
                  
                 <button type="submit" name="simpan" value="simpan" class="btn btn-primary">Simpan <span class="glyphicon glyphicon-ok"></button></a></button>

               
              </div>
            </div>
</div>
          </div>
           </form>


    
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <div class="row">
              <div class="col-md-5">
                <h2 class="footer-heading mb-4">About Us</h2>
                <p>CV. CiliwungCamp Nusantara.<br>
                Jl. Ciliwung I No.76, Purwantoro, Kec. Blimbing, Kota Malang, Jawa Timur 65126.<br>
              0851-0396-5552</p>
              </div>
              <!-- <div class="col-md-3 mx-auto">
                <h2 class="footer-heading mb-4">Quick Links</h2>
                <ul class="list-unstyled">
                  <li><a href="#">About Us</a></li>
                  <li><a href="#">Services</a></li>
                  <li><a href="#">Testimonials</a></li>
                  <li><a href="#">Contact Us</a></li>
                </ul>
              </div> -->
              
            </div>
          </div>
          <!-- <div class="col-md-4">
            <div class="mb-4">
              <h2 class="footer-heading mb-4">Subscribe Newsletter</h2>
            <form action="#" method="post" class="footer-subscribe">
              <div class="input-group mb-3">
                <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="button-addon2">
                <div class="input-group-append">
                  <button class="btn btn-primary text-black" type="button" id="button-addon2">Send</button>
                </div>
              </div>
            </form>  
            </div> -->
            
            <div class="">
              <h2 class="footer-heading mb-4">Follow Us</h2>
                <a href="https://www.facebook.com/CiliwungCampOutdoorService/" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                <a href="https://twitter.com/ciliwungcamp/status/550520866770264064?lang=ar" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                <a href="https://www.instagram.com/ciliwungcamp/?hl=id" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                <!-- <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a> -->
            </div>


          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <div class="border-top pt-5">
            <p class="copyright">
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
            </div>
          </div>
          
        </div>
      </div>
    </footer>

  </div> <!-- .site-wrap -->

  <a href="#top" class="gototop"><span class="icon-angle-double-up"></span></a> 

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>

  
  <script src="js/main.js"></script>
    
  </body>
</html>