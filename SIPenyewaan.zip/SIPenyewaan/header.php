
      <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-6 col-xl-2">
            <h1 class="mb-0 site-logo m-0 p-0"><a href="index2.php" class="mb-0">CIliwungcamp</a></h1>
          </div>

          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <?php 
                      if(!isset($_SESSION['USERNAME'])){
                  ?>

              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
              <li><a href="index2.php" data-hover="Home">Beranda</a></li>
             
              <!-- <li><a href="index_user.php?hal=kontak" data-hover="kontak">Kontak</a></li> -->
              <li><a href="riwayat2.php" data-hover="Riwayat">Riwayat Pesanan</a></li>
              <li><a href="profile2.php" data-hover="profile">Profile</a></li>
              <li><a href="logoutUser.php" data-hover="logout">Logout</a></li>
              </ul>
            </nav>
          </div>
  <?php 
                      }
                  ?>

          <div class="col-6 d-inline-block d-xl-none ml-md-0 py-3"><a href="#" class="site-menu-toggle js-menu-toggle text-white float-right"><span class="icon-menu h3"></span></a></div>

        </div>
      </div>
      
    </header>