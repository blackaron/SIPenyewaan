
<?php

	include "koneksi.php"; 

	if(isset($_POST['update'])) {
	$id_user  = $_GET['ID_USER'];
	$nama = $_POST['nama'];
	$alamat = $_POST['alamat'];
	$nohp= $_POST['notelp'];
	$email= $_POST['email'];
	

		
    $user = mysqli_query($koneksi, "UPDATE user SET NAMA = '$nama',ALAMAT='$alamat',NO_HP='$nohp',EMAIL='$email' WHERE ID_USER='$id_user'") or die ("data salah: ".mysqli_error($koneksi));



		if(!$user ){
		echo "<script>alert('Gagal di tambahkan!');history.go(-1);</script>";
		} else{
		echo "<script>alert('Data berhasil di tambahkan!');history.go(-1);</script>";
	}
}

	else{
		 $user = mysqli_query($koneksi, "UPDATE  user SET  NAMA = '$nama',ALAMAT='$alamat',NO_HP='$nohp',EMAIL='$email' WHERE ID_USER='$id_user'") or die ("data salah: ".mysqli_error($koneksi));	

		if(!$user ){
echo "<script>alert('Gagal di update!');history.go(-1);</script>";
} else{
echo "<script>alert('Data berhasil di update!');history.go(-1);</script>";
}

}
?>