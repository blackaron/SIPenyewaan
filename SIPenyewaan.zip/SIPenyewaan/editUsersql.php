<?php

	include "koneksi.php"; 

	if(isset($_POST['update'])) {
	$idu  = $_GET['ID_USER'];
	$nama = $_POST['NAMA'];
	$alamat = $_POST['ALAMAT'];
	$nohp= $_POST['NO_HP'];
	$email= $_POST['EMAIL'];
	
	// $gambar = $_FILES['GAMBAR_USER']['name'];
	// $lokasi_file = $_FILES['GAMBAR_USER']['tmp_name'];

	// if($gambar != ''){
	// 	$path ="img/".$gambar;
		

	// 	move_uploaded_file($lokasi_file, $path);

		
    $user = mysqli_query($koneksi, "UPDATE user SET NAMA = '$nama',ALAMAT='$alamat',NO_HP='$nohp',EMAIL='$email' WHERE ID_USER='$idu'") or die ("data salah: ".mysqli_error($koneksi));



		if(!$user ){
		echo "<script>alert('Gagal di tambahkan!');history.go(-1);</script>";
		} else{
		echo "<script>alert('Data berhasil di tambahkan!');history.go(-1);</script>";
	}
}

	else{
		$user = mysqli_query($koneksi, "UPDATE user SET NAMA = '$nama',ALAMAT='$alamat',NO_HP='$nohp',EMAIL='$email',GAMBAR_USER='$gambar' WHERE ID_USER='$idu'") or die ("data salah: ".mysqli_error($koneksi));

		if(!$user ){
echo "<script>alert('Gagal di update!');history.go(-1);</script>";
} else{
echo "<script>alert('Data berhasil di update!');history.go(-1);</script>";
}
}
}

?>