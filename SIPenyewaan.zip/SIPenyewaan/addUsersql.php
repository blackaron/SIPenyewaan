<?php
session_start();

include "koneksi.php"; //memanggil file koneksi.php untuk menghubungkan ke database

if(isset($_POST['simpan'])){
	$username = $_POST['USERNAME'];
	$password = $_POST['PASSWORD'];
	$nama= $_POST['NAMA'];
	$alamat= $_POST['ALAMAT'];
	$email= $_POST['EMAIL'];

	// $foto = $_FILES['foto']['name'];
	// $lokasi_file = $_FILES['foto']['tmp_name'];
	
	// $path = "img/".$foto;

	// move_uploaded_file($lokasi_file, $path);


	// // menambahkan query sql tambah data untuk menambahkan untuk data ke database
	$data = mysqli_query($koneksi,"INSERT INTO user set USERNAME='$username', password='$password', NAMA='$nama', EMAIL='$email', level=2") or die ("data salah : ".mysqli_error($koneksi));

	// untuk mengetahui apakah data berhasil disimpan atau belum
	if ($data) {
		echo "<script>alert('Pendaftaran Berhasil');history.go(-2);</script>";
		

	}else{
		echo "<script>alert('Pendaftaran Gagal');history.go(-1);</script>";
		
}
}

?>